package com.AoopProject.LoginWithHibernate;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class OperationsTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	
		//Date date;
		
	//	Operations.AddNewTimeStamp(date, 1, 5, hours, user);
	
		//Operations.GetAllDeparmentId();
	}

	@Test
	public void updateTimeStamp() {
		
	int Id = 4;
	
	Users u = new Users();
	u.SetId(10);
		Operations.updateTimeStamp(Id);
	}
	
	
	
	
}

package TCP_Socket_Client;

import static org.junit.Assert.*;
import java.sql.SQLException;

import org.junit.Test;

public class Insert_Convo_Test {
	
	@Test
	public void test() {
		
		try {
			
	assertEquals(Maria_Convo_Options.insertKeyWord(1, "Hello"),true);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void test_2() {
		
		try {
			
	assertEquals(Maria_Convo_Options.insertRespond(2, "Unknown Statement... Could You Please Rephrase That"),true);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_3() {
		
		try {
			
	assertEquals(Maria_Convo_Options.insertCategory("Error"),true);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

package TCP_Socket_Client;

import static org.junit.Assert.*;

import org.apache.commons.lang3.StringEscapeUtils;
import org.junit.Test;

public class RetrieveChatbotConvo_Test {

	@Test
	public void test() {
		
	String msg ="what is up"; 	
	
	
	System.out.println(msg);
		String msg_2 =	StringEscapeUtils.escapeJava(msg);
		
		RetrieveChatbotConvo.loadChatBot(msg_2);
	}

}

package TCP_Socket_Client;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

public class Maria_Convo_Options_Test {

	/*
	@Test
	public void deleteRow() {
		Maria_Convo_Options.deleteRow("maria_convo_keyword","idmaria_convo", 3);
	}
	*/
	
	@Test
	public void setAppoint() {
		
		Time time = new Time(3, 4, 0);
		Date a =new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		System.out.println(a.getDate());
		a.setDate(4);
		a.setMonth(5);
		a.setYear(2020);
		
		String newDate = dateFormat.format(a.getDate());
		System.out.println("new Date "+newDate);
		
		try {
			Maria_Convo_Options.UploadAppointment("New test", 10, "", newDate, time);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

package TCP_Socket_Client;

import static org.junit.Assert.*;

import org.junit.Test;

public class Assistant_operation_Test {

	@Test
	public void test() {
		
		Assistant_operation selectOP = new Assistant_operation();
		
		
		assertNotNull(selectOP.select(10));
		
		
	}

}

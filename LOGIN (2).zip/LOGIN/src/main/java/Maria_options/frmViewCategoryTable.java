package Maria_options;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import TCP_Socket_Client.Maria_Convo_Options;
import net.proteanit.sql.DbUtils;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmViewCategoryTable extends JInternalFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1830736892281229388L;
	private JTable table;
	static frmViewCategoryTable frame;
	static JPanel panel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new frmViewCategoryTable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	ResultSet rs = null;
	ArrayList<Integer> CatId = new ArrayList<>();
	ArrayList<String> keyContent = new ArrayList<>();
	
	public frmViewCategoryTable() {
        
		setBounds(100, 100, 765, 541);
		
		JButton btnDeleteRow = new JButton("Delete Row");
		btnDeleteRow.setMnemonic('D');
		btnDeleteRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				deleteRow();
				loadTable();
				
			}
		});
		btnDeleteRow.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				
				 
				 UpdateDb();
				 
				 loadTable();
				
			}

			
		});
		btnUpdate.setMnemonic('U');
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(406, Short.MAX_VALUE)
					.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 139, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnDeleteRow)
					.addGap(51))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(69)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnDeleteRow)
						.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(412, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(85, 130, 550, 300);
		getContentPane().add(scrollPane);
		
		table =new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		JTableHeader header = table.getTableHeader();
	    header.setFont(new Font("Tahoma", Font.PLAIN, 22));
	    table.setTableHeader(header);
		table.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		 
		
		scrollPane.setViewportView(table);
		
		loadTable();
		
		panel = new JPanel();
		panel.setSize(new Dimension(250, 100));
	    panel.setLayout(null);
	    
      JLabel label1 = new JLabel("Are You Sure You Want To Delete This Row? ");
      label1.setVerticalAlignment(SwingConstants.BOTTOM);
      label1.setBounds(20, 20, 200, 30);
      label1.setHorizontalAlignment(SwingConstants.CENTER);
      panel.add(label1);
		
	}

	private void loadTable() {
		try {
			rs = Maria_Convo_Options.getAllKeyword("conversation_category");
			table.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void UpdateDb() {
		for (int i = 0; i < table.getRowCount(); i++) {
			
			 CatId.add( Integer.parseInt(table.getValueAt(i,0 ).toString()));
			 keyContent.add(table.getValueAt(i,1 ).toString());
			 
			 
		}
		
		
		 // table.getValueAt(table.getSelectedRow(),0 ).toString();
		 ArrayList<String> fieldName = new ArrayList<>();
		 fieldName.add("categoryId");
		 fieldName.add("category_name");
		
		Maria_Convo_Options.updateRecord("conversation_category",fieldName,CatId,keyContent);
		
		loadTable();
		JOptionPane.showMessageDialog(null, "SucessfulLy Updated Records");
		
	}
	
	
	private void deleteRow() {
		
		if(table.getSelectedRow()<0) {
			
			System.out.println("no row selected");
		}else {
			
			System.out.println(" row selected");
			
			int res = JOptionPane.showConfirmDialog(null, "Are You Sure You Want To Delete This Row? ", "Confirm Deleting Row",JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			      if(res == 0) {
			         System.out.println("Pressed YES");
			         
			         String value = table.getValueAt(table.getSelectedRow(),0 ).toString();
			         Maria_Convo_Options.deleteRow("conversation_category","categoryId" , Integer.parseInt(value));
			         loadTable();
			         JOptionPane.showMessageDialog(null, "SucessfulLy Removed Record");
			      } else if (res == 1) {
			         System.out.println("Pressed NO");
			      } else {
			         System.out.println("Pressed CANCEL");
			      }
		}
		
		 
		
	}

	 	 
}


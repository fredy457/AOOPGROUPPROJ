package Maria_options;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;

import TCP_Socket_Client.ConversationCategory;
import TCP_Socket_Client.Maria_Convo_Options;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class frmInsertKeyWord extends JInternalFrame {
	private JTextField txtTxtkyeword;
	JComboBox cmbCategory;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmInsertKeyWord frame = new frmInsertKeyWord();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	ArrayList<ConversationCategory> list = new ArrayList<>();
	
	public frmInsertKeyWord() {
		setBounds(100, 100, 450, 300);
		
		 cmbCategory = new JComboBox();
		
		
		try {
			list = Maria_Convo_Options.getConvoCategory();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int index = 0;
		for (ConversationCategory conversationCategory : list) {
			cmbCategory.addItem(conversationCategory.getName());		
			
		}
		
		JLabel lblNewLabel = new JLabel("Category");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblKeyword = new JLabel("Keyword");
		lblKeyword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		txtTxtkyeword = new JTextField();
		txtTxtkyeword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtTxtkyeword.setColumns(10);
		
		JButton btnInsertKeyword = new JButton("Insert Keyword");
		btnInsertKeyword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				addKeyword();				
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(28)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(lblKeyword, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(txtTxtkyeword)
								.addComponent(cmbCategory, 0, 215, Short.MAX_VALUE)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(117)
							.addComponent(btnInsertKeyword)))
					.addContainerGap(86, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(45)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(cmbCategory, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblKeyword)
						.addComponent(txtTxtkyeword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(65)
					.addComponent(btnInsertKeyword)
					.addContainerGap(68, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void addKeyword() {
		
		if(txtTxtkyeword.equals("")) {
			txtTxtkyeword.requestFocusInWindow();
		}else {
			
			int id = -1;
			
			for (ConversationCategory conversationCategory : list) {
				if (cmbCategory.getSelectedItem() == conversationCategory.getName()) {
					
					id = conversationCategory.getId();
					
				}
			}
			
			System.out.println(id);
			
			try {
				if (Maria_Convo_Options.insertKeyWord(id, txtTxtkyeword.getText()) == true) {
					System.out.println("Succesfull");
					txtTxtkyeword.setText("");
					txtTxtkyeword.requestFocusInWindow();

					JOptionPane.showMessageDialog(null, "Succesfull");
				}else {
					System.out.println("Unsuccesfull");
				JOptionPane.showMessageDialog(null, "Succesfull");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
			
		}
		
	}
}



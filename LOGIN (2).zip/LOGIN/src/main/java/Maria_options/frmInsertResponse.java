package Maria_options;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import TCP_Socket_Client.ConversationCategory;
import TCP_Socket_Client.Maria_Convo_Options;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class frmInsertResponse extends JInternalFrame {
	private JTextField txtResponse;
	JComboBox cmbCategory;
	ArrayList<ConversationCategory> list = new ArrayList<>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmInsertResponse frame = new frmInsertResponse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmInsertResponse() {
		setBounds(100, 100, 666, 406);
		
		JButton btnInsertResponse = new JButton("Insert Response");
		btnInsertResponse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addKeyword();
			}
		});
		btnInsertResponse.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		txtResponse = new JTextField();
		txtResponse.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtResponse.setColumns(10);
		
		JLabel lblResponse = new JLabel("Response");
		lblResponse.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblNewLabel = new JLabel("Category");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		cmbCategory = new JComboBox();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(129)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(cmbCategory, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblResponse, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtResponse, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(89)
							.addComponent(btnInsertResponse, GroupLayout.PREFERRED_SIZE, 197, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(201, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(104)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(cmbCategory, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblResponse, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(1)
							.addComponent(txtResponse, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)))
					.addGap(65)
					.addComponent(btnInsertResponse)
					.addContainerGap(103, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
		
		try {
			list = Maria_Convo_Options.getConvoCategory();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int index = 0;
		for (ConversationCategory conversationCategory : list) {
			cmbCategory.addItem(conversationCategory.getName());		
			
		}

	}

	protected void addKeyword() {
		
		if(txtResponse.equals("")) {
			txtResponse.requestFocusInWindow();
		}else {
			
			int id = -1;
			
			for (ConversationCategory conversationCategory : list) {
				if (cmbCategory.getSelectedItem() == conversationCategory.getName()) {
					
					id = conversationCategory.getId();
					
				}
			}
			
			System.out.println(id);
			
			try {
				if (Maria_Convo_Options.insertRespond(id, txtResponse.getText()) == true) {
					System.out.println("Succesfull");
				}else {
					System.out.println("Unsuccesfull");
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
			
		}
		
	}

}

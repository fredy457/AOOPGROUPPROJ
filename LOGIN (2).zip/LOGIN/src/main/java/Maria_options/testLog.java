package Maria_options;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class testLog {

	static Logger log = Logger.getLogger(testLog.class);
	
	public static void main(String[] args) {
		
			System.out.println("====> Please insert a number from 0 to 100 : \n====> ");
			Scanner c =  new Scanner(System.in);
			int i = c.nextInt();
	        
	      
	        
	        log.info("You inserted the number:"+i);
	        if(i > 100) {
	            log.error("You entered a wrong number!");
	         
	        } else {
	            log.debug("Number is smaller than 100, so it is correct!");
	        }

		
	}

}

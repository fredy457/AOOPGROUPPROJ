package TCP_Socket_Client;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Logger;


public class Server  {
	 static Logger log = Logger.getLogger(Server.class);
	
	public static final int PORT =4444; 
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		new Server().runServer();
	}

	public  void runServer() throws IOException, ClassNotFoundException {
		 
		System.out.println("Server Up and Ready......");
		log.info("Server Up and Ready......");
		ServerSocket ss = new ServerSocket(PORT);
		
		System.out.println("Server Waiting For New  Connection......");
		while(true) {
			
		
		Socket socket = ss.accept();
		log.info("Server connected......");
		System.out.println("Server connected......");
				
		ServerThread t = new ServerThread(socket);
		
		t.start();
		log.info("New Thread Start......");
		}
		
	
	}

	
}

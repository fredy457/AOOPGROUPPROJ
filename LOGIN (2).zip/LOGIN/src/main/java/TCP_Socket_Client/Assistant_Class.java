package TCP_Socket_Client;

import org.springframework.stereotype.Component;

@Component("Assistant_Class")
public class Assistant_Class {

	
	private String Title;  
	private String Description;
	private String Date;
	private String Time;
	
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	
	public Assistant_Class(String title, String description, String date, String time) {
		
		Title = title;
		Description = description;
		Date = date;
		Time = time;
	}
	public Assistant_Class() {
		// TODO Auto-generated constructor stub
	}
	
	
}

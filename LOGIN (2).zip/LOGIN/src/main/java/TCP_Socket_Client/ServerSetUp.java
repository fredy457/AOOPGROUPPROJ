package TCP_Socket_Client;

public class ServerSetUp {

	public static void main(String[] args) {
		
		

	}

}

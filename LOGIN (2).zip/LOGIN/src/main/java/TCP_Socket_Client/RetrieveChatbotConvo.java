package TCP_Socket_Client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

import org.apache.log4j.Logger;

public class RetrieveChatbotConvo {

	static String dBUsername = "root";
	
	static String dBPassword = "";
	 static Logger log = Logger.getLogger(RetrieveChatbotConvo.class);
	 
	public static void main(String[] args) {
		
	}
	
	
	public static ArrayList<Message> loadChatBot(String msg) {
		 ArrayList<Message> resArray = new ArrayList<Message>();
		try{  
	        /****Registering the Database Driver for MySQL ****/	
        	Class.forName("com.mysql.cj.jdbc.Driver"); 
	        
	        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aoopdb",dBUsername,dBPassword);  
	        	
	        /****  Creating the statement****/		        	
        	Statement stmt=con.createStatement();  
	        	
        	/***** Executing the Statement and getting the Result ***/
        	
        
	        ResultSet key=stmt.executeQuery( "select * from maria_convo_keyword where keyword = '"+ msg +"'"); 	
	        
	           
	        //key.beforeFirst();
	        String k="";
	        
	        while (key.next()) {
				k = key.getString(3);				
				System.out.println(k);
			}
	        if(k =="") {
	        	k="2";
	        }
	        
	        
	        ResultSet res =stmt.executeQuery("select response,categoryid from maria_convo_response where categoryid ="+ Integer.parseInt(k) +"");
	        int i = 0;
	       
	      
	        
	        while (res.next()) {
	        	
	        resArray.add(new Message(res.getString(1),res.getString(2)) );
	        
				
			}
	        
	       
	   
	        /***** Closing the connection ***/	
	        con.close();  
        	}catch(Exception e){
        		log.error("Error throw while retrieving Chat  ");
        		System.out.println(e);
        	e.printStackTrace();	
        	}
		
		return resArray;
		
	}
}


package TCP_Socket_Client;

import java.util.ArrayList;

public interface DB_CRUD {

	ArrayList<Assistant_Class> select(int id);
}

package TCP_Socket_Client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

public class Assistant_operation implements DB_CRUD {

	 // JDBC driver name and database URL
	 static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	 static final String DB_URL = "jdbc:mysql://localhost/aoopdb";
	
	 //  Database credentials
	 static final String USER = "root";
	 static final String PASS = "";
	 
	 static Connection conn = null;
	 static Statement stmt = null;
	 
	 static Logger log = Logger.getLogger(Maria_Convo_Options.class);
	 
	 public static void ConnectDb() {
		 

			    try {
		    	//STEP 2: Register JDBC driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				//STEP 3: Open a connection
				// System.out.println("Connecting to a selected database...");
		   
				log.info("Connecting to a selected database...");
		    
				conn = DriverManager.getConnection(DB_URL, USER, PASS);
				log.info("Connected database successfully...");
			    
			    //System.out.println("Connected database successfully...");
				
			    } catch (ClassNotFoundException e) {
					log.error("Class Not Found Exception");
					e.printStackTrace();
				} catch (SQLException e) {
					log.fatal("SQL Exception");
					e.printStackTrace();
				} 

	}
	 
	
	@Override
	public ArrayList<Assistant_Class> select(int id) {
		ConnectDb();
		

		 ArrayList<Assistant_Class> list = new ArrayList<Assistant_Class>();
		 Date today = new Date();
		 Date d_2 = new Date();
		 SimpleDateFormat sim =  new SimpleDateFormat("yyyy-MM-dd");
		 
		 
			
		 try {
			today = sim.parse(sim.format(Calendar.getInstance().getTime()));
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		
		 
		 	//System.out.println("Getting records from the table...");
		 	log.info("Getting Conversation Category records from the table...");
		 	try {
				stmt = conn.createStatement();
				String sql= "SELECT * FROM appointmentdb WHERE UserId = "+id+" ; ";
				System.out.println(sql);
		    ResultSet rs = stmt.executeQuery(sql);
		    log.info("Conversation Category SQL Executed...");
		   // int index =0;
		    
		    while (rs.next()) {
				
		    	try {
					d_2 = sim.parse(rs.getString(5));
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	
		    	if(today.before(d_2)) {
		    		
		    		list.add(new Assistant_Class(rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)));
		    	}
		    	
		    	
		    	
				
				//list.add(new ConversationCategory(rs.getInt(1),rs.getString(2)));
			//	index++;
				
			}
		     //System.out.println("Returning...");
		    log.info("Returning List...");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		    
		 	
		    return list;
		
		
	
	}

		

}

package TCP_Socket_Client;
//STEP 1. Import required packages
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

public class Maria_Convo_Options {
	
	 // JDBC driver name and database URL
	 static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	 static final String DB_URL = "jdbc:mysql://localhost/aoopdb";
	
	 //  Database credentials
	 static final String USER = "root";
	 static final String PASS = "";
	 
	 static Connection conn = null;
	 static Statement stmt = null;
	 
	 static Logger log = Logger.getLogger(Maria_Convo_Options.class);
	 
	 public static void ConnectDb() {
		 

			    try {
		    	//STEP 2: Register JDBC driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				//STEP 3: Open a connection
				// System.out.println("Connecting to a selected database...");
		   
				log.info("Connecting to a selected database...");
		    
				conn = DriverManager.getConnection(DB_URL, USER, PASS);
				log.info("Connected database successfully...");
			    
			    //System.out.println("Connected database successfully...");
				
			    } catch (ClassNotFoundException e) {
					log.error("Class Not Found Exception");
					e.printStackTrace();
				} catch (SQLException e) {
					log.fatal("SQL Exception");
					e.printStackTrace();
				} 

	}
	 
	 
	 
	public static boolean insertKeyWord(int cat_id,String keyword) throws SQLException {
		ConnectDb();
		
		//System.out.println("Inserting records into the table...");
		log.info("Inserting New Keyword Record into the table...");
	    stmt = conn.createStatement();	
	    String sql= "INSERT INTO maria_convo_keyword (keyword,categoryid) VALUES ('"+keyword +"',"+ cat_id+" )";
	    
	   if (stmt.executeUpdate(sql) >0) {
		   log.info("Keyword Record Inserted Sucessfully..."); 
		return true;
	   }
	   log.error("Keyword Record Inserted Sucessfully..."); 
	    return false;
	}
	
	public static boolean insertRespond(int cat_id,String res) throws SQLException {
		ConnectDb();
		
		//System.out.println("Inserting records into the table...");
	    log.info("Inserting New Respond record into the table...");
		stmt = conn.createStatement();	
	    String sql= "INSERT INTO maria_convo_response (response,categoryid) VALUES ('"+res +"',"+ cat_id+" )";
	    
	   if (stmt.executeUpdate(sql) >0) {
		   log.info("Respond Record Inserted Sucessfully..."); 
		return true;
	   } 
	   log.error("Respond Record Inserted Sucessfully...");
	    return false;
	}
	
	public static boolean insertCategory(String category) throws SQLException {
		ConnectDb();
		
		//System.out.println("Inserting records into the table...");
	    log.info("Inserting New Category record into the table...");
		stmt = conn.createStatement();	
	    String sql= "INSERT INTO conversation_category (category_name) VALUES ('"+category +"' )";
	    
	   if (stmt.executeUpdate(sql) >0) {
		   log.info("Category Record Inserted Sucessfully...");
		return true;
	   } 
	   log.error("Category Record Inserted Sucessfully...");
	    return false;
	}
	
	public static ArrayList<ConversationCategory> getConvoCategory() throws SQLException {
		
		 ArrayList<ConversationCategory> list = new ArrayList<ConversationCategory>();
		 ConversationCategory cc = new ConversationCategory();
		 
		 ConnectDb();
		 
		 	//System.out.println("Getting records from the table...");
		 	log.info("Getting Conversation Category records from the table...");
		 	stmt = conn.createStatement();	
		    String sql= "SELECT * FROM conversation_category; ";
			
		    ResultSet rs = stmt.executeQuery(sql);
		    log.info("Conversation Category SQL Executed...");
		   // int index =0;
		    
		    while (rs.next()) {
				
				
				list.add(new ConversationCategory(rs.getInt(1),rs.getString(2)));
			//	index++;
				
			}
		     //System.out.println("Returning...");
		    log.info("Returning List...");
		    return list;
		    
		    		 
	}
	
	public static ResultSet getAllKeyword(String tableName) throws SQLException {
		
		 ConnectDb();
		 
		 	//System.out.println("Getting records from the table...");
		 	log.info("Getting All of the Keyword records from the table...");
		 	stmt = conn.createStatement();	
		    String sql= "SELECT * FROM "+tableName+" ; ";
			
		    ResultSet rs = stmt.executeQuery(sql);
		    log.info("Conversation Category SQL Executed...");
		   // int index =0;
		    
		     //System.out.println("Returning...");
		    log.info("Returning Result...");
		    return rs;
		    		 
	}
	 
	public static void deleteRow(String tableName,String idFieldName,int id)  {
		ConnectDb();
		 
	 	//System.out.println("Getting records from the table...");
	 	log.info("Deleting Record From "+ tableName+" .....");
	 	try {
			stmt = conn.createStatement();
			String sql= "Delete FROM "+tableName+" Where "+idFieldName +"="+id+" ; ";
		
	    stmt.executeUpdate(sql);
	    log.info("Record Deleted Sucessful...");
		} catch (SQLException e) {
			log.error("Sql Exception thrown... Possible Error include : 1) Incorrect parameter\n 2) then is the data is already delete");
			e.printStackTrace();
		}	
	
	    
	}
	public static void UploadAppointment(String Title, int id, String Descript, String date, Time time) throws SQLException {
		ConnectDb();
		
	
		
		//System.out.println("Inserting records into the table...");
		log.info("Inserting New Keyword Record into the table...");
	    stmt = conn.createStatement();	
	    String sql= "INSERT INTO appointmentdb (UserId,Title,Description,Date,Time) VALUES ("+id+",'"+ Title+ "','"+Descript +"','"+date+"','" + time+"')";																				
	    
	    System.out.println(sql);
	    
	   if (stmt.executeUpdate(sql) >0) {
		   log.info("Appointment Record Inserted Sucessfully..."); 
		
	   }else {
	   log.error("Appointment Record Inserted Sucessfully..."); 
	   }
	}
	
	public static void updateRecord(String tableName,ArrayList<String>  fieldName , ArrayList<Integer> keyId,ArrayList<String> keyContent,ArrayList<Integer> categoryId) {
		ConnectDb();
		 
	 	//System.out.println("Getting records from the table...");
	 	log.info("Updating Record From "+ tableName+" .....");
	 	try {
			stmt = conn.createStatement();
			
			for (int i = 0; i < keyId.size(); i++) {
				
		String sql= "UPDATE " +tableName+" Set "+fieldName.get(1)+ " = '"+keyContent.get(i)+ "',"+fieldName.get(2)+ " =  "+categoryId.get(i) +" Where "+fieldName.get(0)+"="+keyId.get(i);  
		//System.out.println(sql);
			stmt.executeUpdate(sql);
			
			}

	    log.info("Record Update Sucessful...");
		} catch (SQLException e) {
			log.error("Sql Exception thrown... Possible Error include : 1) Incorrect parameter\n 2) then is the data is already delete");
			e.printStackTrace();
		}	
	}
	
	
	public static void updateRecord(String tableName,ArrayList<String>  fieldName , ArrayList<Integer> keyId,ArrayList<String> keyContent) {
		ConnectDb();
		 
	 	//System.out.println("Getting records from the table...");
	 	log.info("Updating Record From "+ tableName+" .....");
	 	try {
			stmt = conn.createStatement();
			
			for (int i = 0; i < keyId.size(); i++) {
				
		String sql= "UPDATE " +tableName+" Set "+fieldName.get(1)+ " = '"+keyContent.get(i)+"' Where "+fieldName.get(0)+"="+keyId.get(i);  
		System.out.println(sql);
			stmt.executeUpdate(sql);
			
			}

	    log.info("Record Update Sucessful...");
		} catch (SQLException e) {
			log.error("Sql Exception thrown... Possible Error include : 1) Incorrect parameter\n 2) then is the data is already delete");
			e.printStackTrace();
		}	
	}
	
	
	 public static void main(String[] args) {
	 
		 
		 try {
			 ArrayList<ConversationCategory> list = getConvoCategory();
			 int i = 0;
			 for (ConversationCategory conversationCategory : list) {
				System.out.println(list.get(i));
				i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	
	 }//end main
	}//end Insert
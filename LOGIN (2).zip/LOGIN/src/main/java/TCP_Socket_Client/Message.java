package TCP_Socket_Client;

import java.io.Serializable;

public class Message implements Serializable{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
	private String function;

	public Message() {
	
		
	}
	
	
	public String getFunction() {
		return function;
	}


	public void setFunction(String function) {
		this.function = function;
	}


	public Message(String message) {
		
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	public Message(String message, String function) {

		this.message = message;
		this.function = function;
	}


	@Override
	public String toString() {
		return "Message [message=" + message + ", function=" + function + "]";
	}


	
	
	
	
	
}

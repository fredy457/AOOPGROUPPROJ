package TCP_Socket_Client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.Logger;

import com.AoopProject.LoginWithHibernate.frmLogin;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmServerGui extends JFrame {

	private JPanel contentPane;
	static Logger log = Logger.getLogger(frmServerGui.class);

	JButton btnStopServer;
	JButton btnStartServer;
	ServerSocket ss;
	Socket socket;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmServerGui frame = new frmServerGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmServerGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnStartServer = new JButton("START SERVER");
		btnStartServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnStartServer.setVisible(false);
				btnStopServer.setVisible(true);
				try {
					StartServer();
				} catch (IOException e1) {
					
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnStartServer.setFont(new Font("Tahoma", Font.PLAIN, 32));
		
		btnStopServer = new JButton("STOP SERVER");
		btnStopServer.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					StopServer();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnStopServer.setFont(new Font("Tahoma", Font.PLAIN, 32));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(84)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(btnStartServer, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnStopServer, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
					.addContainerGap(93, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(67)
					.addComponent(btnStopServer, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnStartServer, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(82))
		);
		contentPane.setLayout(gl_contentPane);
		btnStopServer.setVisible(false);
	}

	private void StartServer() throws IOException {
		
			//System.out.println("Server Up and Ready......");
			log.info("Server Up and Ready......");
			ss = new ServerSocket(Server.PORT);
			log.info("Server Waiting For New  Connection......");
			
		
			
			while(true) {
				
			//System.out.println("Server Waiting For New  Connection......");
			socket = ss.accept();
			log.info("New Client connected To Server ......");
			//System.out.println("Server connected......");
					
			ServerThread t = new ServerThread(socket);
			t.start();
			log.info("New Thread Start");
		}
	}
	
	private void StopServer() throws IOException {
		
		socket.close();
		btnStartServer.setVisible(true);
		btnStopServer.setVisible(false);
		
		
	}
}

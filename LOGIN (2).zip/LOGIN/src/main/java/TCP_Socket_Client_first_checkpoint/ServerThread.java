package TCP_Socket_Client_first_checkpoint;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerThread extends Thread{
	
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Socket socket;
	
	
	public ServerThread(Socket s) {
		
		this.socket = s;
		
	}



	@Override
	public void run() {
		
		Message data = null;
		Message rPacket = null;
				try {
					in = new ObjectInputStream(socket.getInputStream());
					out = new ObjectOutputStream(socket.getOutputStream());
		     		
				
		     
						
					
				while(( rPacket = (Message)in.readObject()) !=null) {
					
		     		System.out.println("not null " + rPacket.getMessage());
				
					
					doSomething(rPacket);
					
					//rPacket = new Message();
					
					
					//rPacket.setMessage("Set : Hello .. "+rPacket.getMessage());
					//out.writeObject(rPacket);
				
					
					
				}
				
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}catch( ClassNotFoundException e) {
					
					e.printStackTrace();
				}
				
			//	
				
				//s.close();
		
	}



	private void doSomething(Message data) throws IOException {
		System.out.println("get :"+data.getMessage());
		
		String msg = data.getMessage();
		
		System.out.println("-->You:\t"+msg);
	      msg = msg.trim();
	      while(msg.charAt(msg.length()-1)=='!'|| msg.charAt(msg.length()-1)=='.'|| msg.charAt(msg.length()-1)=='?'
	              ){
	      msg= msg.substring(0,msg.length()-1);
	      }
	      msg=msg.trim();
		

	      byte response=0;
	      String serverRes = null;
	      /*
	      0:we're searching through chatBot[][] for matches
	      1:we didn't find anything in chatBot[][]
	      2:we did find something in chatBot[][]
	      */
	       //------check for matches-------
	       int j=0; //which group we are checking
	       while(response==0){
	       if(inArray(msg.toLowerCase(),chatBot[j*2])){
	           response=2;
	           int r = (int)Math.floor(Math.random()*chatBot[(j*2)+1].length);
	           serverRes ="\n-->Maria\t"+chatBot[(j*2)+1][r]; 
	           
	       }
	       j++;
	       if(j*2== chatBot.length-1 && response==0){
	           response=1;
	       }
	    }
	      
	      // --------default--------------
	      if(response==1){
	         int r = (int)Math.floor(Math.random()*chatBot[chatBot.length-1].length);
	        // System.out.println("\n-->Maria\t"+chatBot[chatBot.length-1][r]);
	         serverRes ="\n-->Maria\t"+chatBot[chatBot.length-1][r];
	      }
	      	System.out.println(serverRes);
	      	System.out.println("\n");
	      	data.setMessage(serverRes);
	      	out.writeObject(data);
	      	
	  }
		
	
	
	private boolean inArray(String in,String[] str) {
		boolean match =false;
	    for(int i=0;i<str.length;i++){
		    if(str[i].equals(in)){
		    match=true;
		    }
	    }
    return match;
    }
	



	String[][] chatBot={
		     // standard greetings
		      {"hi","hello","hola","ola","hey","howdy","good morning","good day"},
		      {"what is your name?","who are you"},
		      //questions
		      {"kyle","mark","chad","dahlia"},
		      {"what position are you applying for?"},
		      
		      {"ceo","business execuctive","manger","janitior"},
		      {"do you have the qualifications for this job?","do you have any experience with this job?"},
		      
		      {"professional thief","thief"},
		      {"What can you steal?","we are sorry we have enough thieves at edwin Allen"},
		      
		      {""},
		      {""},
		      
		      {"anything","everything","I rob banks in my spare time",},
		      {"ok in my spare time I'll call the cops","ok bye"},
		      
		      {"yes","yes i do"},
		      {"ok then mail your resume to this address;\n Waterworks\n Frankfield P.O \n Clarendon "},
		      
		      {"no","no i dont","no i don't"},
		      {"sorry but you are not qualified","thank you for your time but dont call us we'll call "},
		      
		      {"ok","ok then","kl","ok kl"},
		      {"bye"},
		      
		      {"tell me","tell me plz",},
		      {"you go first","nope","ok"},
		     //question greetings 
		      {"how are you","how r you","how r u","how are u"},
		      {"good","doing well"},
		      
		      {"i wanna kiss you","come here","sml"},
		      {"really","ok but you have to tell me what u like about me first"},
		      
		      {"y","why",},   
		      {"i just dont","forget it"},
		    //default  
		      {"shutup","you're bad","noob","stop talking",
		      "( unavailable)"}
		      
		  };
		   
	

}

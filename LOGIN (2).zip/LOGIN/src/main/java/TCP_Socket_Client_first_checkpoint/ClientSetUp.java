package TCP_Socket_Client_first_checkpoint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class ClientSetUp {

	ObjectOutputStream out;
	ObjectInputStream in;
	private Socket socket;
	BufferedReader Buffreader;
	
	public static void main(String[] args) throws Exception {
		new ClientSetUp();			
	}
	
	
	public ClientSetUp()  throws Exception {
		
		
		socket = new Socket("127.0.0.1",Server.PORT);
		System.out.println("Client Connected...");
		out = new ObjectOutputStream(socket.getOutputStream());		
		in = new ObjectInputStream(socket.getInputStream());
		Buffreader = new BufferedReader(new InputStreamReader(System.in));
		int i = 0;
		String message;
		Scanner reeader = new Scanner(System.in);	
		Message data = new Message();
		
		
		while(true) {
			
			
			 //Buffreader.readLine();  
			message = Buffreader.readLine(); 
			
			
			//System.out.println(message); 
		
			if(message.equalsIgnoreCase("exit")) {
				break;
			}
				
		
			data.setMessage(message);//messagex
		//	System.out.println(data.getMessage());
			out.writeObject(data);
			
			
			/*
			message = reader.next();
			data.setMessage(message);
			*/
			
			
			data = (Message) in.readObject();
			System.out.println(data.getMessage());
			
			//srPacket.setMessage("");
			
			//messageFromServer = socketScanner.next();
		
		}
		
		
		
		socket.close();
		
	}
	
	
	
	
	
}

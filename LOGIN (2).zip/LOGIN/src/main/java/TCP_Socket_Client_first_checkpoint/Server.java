package TCP_Socket_Client_first_checkpoint;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class Server  {

	
	public static final int PORT =4444; 
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		new Server().runServer();
	}

	public  void runServer() throws IOException, ClassNotFoundException {
		
		System.out.println("Server Up and Ready......");
		ServerSocket ss = new ServerSocket(PORT);
		
		while(true) {
			
		System.out.println("Server Waiting For New  Connection......");
		Socket socket = ss.accept();
		System.out.println("Server connected......");
				
		ServerThread t = new ServerThread(socket);
		t.start();
		}
		
	
	}

	
}

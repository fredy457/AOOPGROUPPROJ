package TCP_Socket_Client_second_checkpoint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class ClientSetUp {

	ObjectOutputStream out;
	ObjectInputStream in;
	private Socket socket;
	BufferedReader Buffreader;
	private String serverName;
	private int port;
	Message data = new Message();
	
	ClientSetUp(String serverName, int port){
		this.serverName =serverName;
		this.port = port;
	}
	
	
	public static void main(String[] args) throws Exception {
		new ClientSetUp();			
	}
	
	
	
	
	public ClientSetUp()  throws Exception {
		
		connection();
		String message;
		/*
		int i = 0;
		Scanner reeader = new Scanner(System.in);	*/
		
		
		
		while(true) {
			
			
			 
			message = Buffreader.readLine(); 
			
			 
		
			if(message.equalsIgnoreCase("exit")) {
				break;
			}else {
				sendMessage(message);
				getMessage();
			}
				
		
			
			
			
			
			
		
		}
		
		
		
		socket.close();
		
	}


	private void sendMessage(String message) throws IOException {

		data.setMessage(message);
		out.writeObject(data);

	}

	private Message getMessage() throws ClassNotFoundException, IOException {
	
			data = (Message) in.readObject();
			System.out.println(data.getMessage());
			
			return data;
	}

	public void connection() throws UnknownHostException, IOException {
		
		socket = new Socket("127.0.0.1",Server.PORT);
		System.out.println("Client Connected...");
		out = new ObjectOutputStream(socket.getOutputStream());		
		in = new ObjectInputStream(socket.getInputStream());
		Buffreader = new BufferedReader(new InputStreamReader(System.in));
	}
	
	
	
	
	
}

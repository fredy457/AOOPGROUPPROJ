package com.AoopProject.LoginWithHibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "department")
public class Department {

	private static final long serialVersionUID = 3L;
	
	@Id
	@Column(name="Department_Id")
	private String id;
	
	@Column(name= "Department_Name")
	private String Depart_Name;

	public String getDepart_id() {
		return id;
	}

	public void setDepart_id(String depart_id) {
		id = depart_id;
	}

	public String getDepart_Name() {
		return Depart_Name;
	}

	public void setDepart_Name(String depart_Name) {
		Depart_Name = depart_Name;
	}
	
	
}

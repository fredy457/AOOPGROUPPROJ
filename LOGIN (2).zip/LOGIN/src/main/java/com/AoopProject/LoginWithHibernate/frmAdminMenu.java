package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.Logger;

import Maria_options.frmInsertKeyWord;
import Maria_options.frmInsertNewCategory;
import Maria_options.frmInsertResponse;
import Maria_options.frmViewCategoryTable;
import Maria_options.frmViewKeyWordTable;
import Maria_options.frmViewResponseTable;

import javax.swing.JDesktopPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;
import java.awt.event.InputEvent;
import javax.swing.JLabel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class frmAdminMenu extends JFrame {

	private JPanel contentPane;
	JDesktopPane desktopPane;
	static Admin a;
	static Logger log = Logger.getLogger(frmAdminMenu.class);

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmAdminMenu frame = new frmAdminMenu(a);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param a 
	 */
	public frmAdminMenu(Admin a) {
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
		int confirmed = JOptionPane.showConfirmDialog(null, 
		        "Are you sure you want to exit the program?", "Exit Program Message Box",
		        JOptionPane.YES_NO_OPTION);

		    if (confirmed == JOptionPane.YES_OPTION) {
				      dispose();
				
		    	}
				
			}
		});
		
		frmAdminMenu.a =a;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 949, 521);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setMnemonic('F');
		menuBar.add(mnFile);
		
		JMenu mnAppointment = new JMenu("Appointment");
		mnFile.add(mnAppointment);
		
		JMenuItem mntmSetAppointment = new JMenuItem("Set Appointment");
		mntmSetAppointment.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				gotoSetAppointmentMenu();
			}
		});
		mnAppointment.add(mntmSetAppointment);
		
		JMenuItem mntmViewAppointment = new JMenuItem("View Appointment");
		mntmViewAppointment.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				
				
				frmViewAppointment appoint = new frmViewAppointment(a.getId());
				desktopPane.add(appoint);
				appoint.setClosable(true);
				appoint.setVisible(true);
				
				
			}
		});
		mnAppointment.add(mntmViewAppointment);
		
		JMenuItem mntmMaria = new JMenuItem("Maria");
		mntmMaria.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				frmMaria_interanl maria;
				maria = new frmMaria_interanl();
				desktopPane.add(maria);
				maria.setClosable(true);
				maria.setVisible(true);
			}
		});
		mnFile.add(mntmMaria);
		
		JMenu mnMariaOptions = new JMenu("Maria Options");
		mnMariaOptions.setMnemonic('M');
		mnFile.add(mnMariaOptions);
		
		JMenuItem mntmAddKeyword = new JMenuItem("Add Keyword");
		mntmAddKeyword.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyChar() == KeyEvent.VK_ENTER) {
					goTOinsertKey();
				}
			}
		});
		mntmAddKeyword.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				goTOinsertKey();

			}
		});
		mnMariaOptions.add(mntmAddKeyword);
		
		JMenuItem mntmAddRespond = new JMenuItem("Add Respond");
		mntmAddRespond.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyChar() == KeyEvent.VK_ENTER) {
					goTOinsertRes();
				}
			}
		});
		mntmAddRespond.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				goTOinsertRes();
			}
		});
		mnMariaOptions.add(mntmAddRespond);
		
		JMenuItem mntmAddNewCategory = new JMenuItem("Add New Category");
		mntmAddNewCategory.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				gotToCategory();
			}
		});
		mnMariaOptions.add(mntmAddNewCategory);
		
		JRadioButtonMenuItem rdbtnmntmViewKeywordTabke = new JRadioButtonMenuItem("View Keyword Table");
		rdbtnmntmViewKeywordTabke.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
			}
		});
		rdbtnmntmViewKeywordTabke.setMnemonic('K');
		rdbtnmntmViewKeywordTabke.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				viewKeyTable();
			}
		});
		mnMariaOptions.add(rdbtnmntmViewKeywordTabke);
		
		JMenuItem mntmViewRespondTable = new JMenuItem("View Respond Table");
		mntmViewRespondTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				viewResponseTable();
			}
		});
		mnMariaOptions.add(mntmViewRespondTable);
		
		JMenuItem mntmViewCategoryTable = new JMenuItem("View Category Table");
		mntmViewCategoryTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				viewCategoryTable();
			}
		});
		mnMariaOptions.add(mntmViewCategoryTable);
		
		JMenuItem mntmLogOff = new JMenuItem("Log Off");
		mntmLogOff.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				logoff();
			}
		});
		
		mnFile.add(mntmLogOff);
		
		JLabel lblUsername = new JLabel("");
		menuBar.add(lblUsername);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		desktopPane = new JDesktopPane();
		contentPane.add(desktopPane, BorderLayout.CENTER);
		
		lblUsername.setText(a.getFName()+" "+a.getLName());
	}
	
	private void viewKeyTable() {
		frmViewKeyWordTable view = new frmViewKeyWordTable();
		desktopPane.add(view);
		view.setClosable(true);
		view.setVisible(true);
		
		
		view.isResizable();
		
	}

	private void logoff() {
		log.info("Admin Logged Out");
		frmLogin l = new frmLogin();
		l.show();
		setVisible(false);
	}
	
	private void gotToCategory() {
	
		frmInsertNewCategory cat = new frmInsertNewCategory();
				desktopPane.add(cat);
				cat.setClosable(true);
				cat.setVisible(true);
				cat.isResizable();
	}
	
	private void gotoSetAppointmentMenu() {
		
		frmSetAppointment appoint = new frmSetAppointment(a.getId());
				desktopPane.add(appoint);
				appoint.setClosable(true);
				appoint.setVisible(true);
				appoint.isResizable();
	}
	

	private void goTOinsertKey() {
				frmInsertKeyWord key = new frmInsertKeyWord();
				desktopPane.add(key);
				key.setClosable(true);
				key.setVisible(true);
				key.isResizable();
	}
	private void goTOinsertRes() {
		
		frmInsertResponse res = new frmInsertResponse();
		desktopPane.add(res);
		res.setClosable(true);
		res.setVisible(true);
		res.isResizable();
		
	}
	
	private void viewResponseTable() {
		
		frmViewResponseTable Viewres = new frmViewResponseTable();
		desktopPane.add(Viewres);
		Viewres.setClosable(true);
		Viewres.setVisible(true);
		Viewres.isResizable();
	}
	
	private void viewCategoryTable() {
		
		frmViewCategoryTable Viewcat = new frmViewCategoryTable();
		desktopPane.add(Viewcat);
		Viewcat.setClosable(true);
		Viewcat.setVisible(true);
		Viewcat.isResizable();
	}
}

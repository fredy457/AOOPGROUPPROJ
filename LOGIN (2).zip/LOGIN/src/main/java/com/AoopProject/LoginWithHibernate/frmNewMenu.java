package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.Logger;

import javax.swing.JDesktopPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.UnknownHostException;
import javax.swing.JLabel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class frmNewMenu extends JFrame {

	private JPanel contentPane;
	private static Users u ;
	
	private static int time_id =-1;
	static frmNewMenu frame;
	
	JDesktopPane desktopPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new frmNewMenu(u,time_id);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the frame.
	 * 

	 */
	
	
	public frmNewMenu(Users u,int time_id) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
					logoff();
			}
		});
		
		this.u = u;
		this.time_id = time_id;	
		
		initialize();
	}
	
	static Logger log = Logger.getLogger(frmNewMenu.class);
	
	private void initialize() {
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 786, 525);
		
		
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		 desktopPane = new JDesktopPane();
		contentPane.add(desktopPane, BorderLayout.CENTER);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setMnemonic('F');
		menuBar.add(mnFile);
		
		JMenuItem mntmMaria = new JMenuItem("Maria");
		mntmMaria.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				frmMaria_interanl maria;
				maria = new frmMaria_interanl();
				desktopPane.add(maria);
				maria.setClosable(true);
				maria.setVisible(true);
				
				
			}
		});
		
		JMenu mnAppointment = new JMenu("Appointment");
		mnFile.add(mnAppointment);
		
		JMenuItem mntmSetAppointment = new JMenuItem("Set Appointment");
		mntmSetAppointment.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				gotoSetAppointmentMenu();
			}
		});
		mnAppointment.add(mntmSetAppointment);
		
		JMenuItem mntmViewAppointment = new JMenuItem("View Appointment");
		mntmViewAppointment.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				frmViewAppointment appoint = new frmViewAppointment(u.getId());
				desktopPane.add(appoint);
				appoint.setClosable(true);
				appoint.setVisible(true);
			}
		});
		mnAppointment.add(mntmViewAppointment);
		
		
		
		mnFile.add(mntmMaria);
		
		JMenuItem mntmLogOff = new JMenuItem("Log Off");
		mntmLogOff.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				logoff();
				
			}
		});
		mnFile.add(mntmLogOff);
		
		JLabel lblUsername = new JLabel("Username");
		menuBar.add(lblUsername);
		lblUsername.setText(u.getFName()+" "+ u.getLName());
		
		
		
	}

	private void logoff() {
		
		int confirmed = JOptionPane.showConfirmDialog(null, 
		        "Are you sure you want to exit the program?", "Exit Program Message Box",
		        JOptionPane.YES_NO_OPTION);

		    if (confirmed == JOptionPane.YES_OPTION) {
				      dispose();
				      
				log.info("User Logged Out");
				Operations.updateTimeStamp(time_id);
				
				frmLogin l = new frmLogin();
				l.show();
				setVisible(false);
		    }
		
		
		
	}
	
	private void gotoSetAppointmentMenu() {
		
		frmSetAppointment appoint = new frmSetAppointment(u.getId());
				desktopPane.add(appoint);
				appoint.setClosable(true);
				appoint.setVisible(true);
				appoint.isResizable();
	}
}

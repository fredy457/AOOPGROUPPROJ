package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import TCP_Socket_Client.Message;
import TCP_Socket_Client.Server;

import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmMaria extends JFrame {

	private JPanel contentPane;
	private JTextField txtChatbox;
	ObjectOutputStream out;
	ObjectInputStream in;
	private Socket socket;
	BufferedReader Buffreader;
	private String serverName;
	private int port;
	Message data = new Message();
	static frmMaria frame;
	
	private static Users user ;
	private static int time_id =-1;
	
	JTextArea txtrChatarea;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new frmMaria();
					frame.setVisible(true);
					
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
		
		
	}

	/**
	 * Create the frame.
	 */
	
	public frmMaria(String serverName, int port){
		this.serverName =serverName;
		this.port = port;
		
		
	}
	
	
	public frmMaria(Users u, int time_id) throws UnknownHostException, IOException {
		
		this.user = u;
		this.time_id = time_id;	
		
		intialize();	
			
			
		}
	
	public frmMaria() throws UnknownHostException, IOException {
		
	intialize();	
		
		
	}
	
	
	

	private void intialize() {

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				try {
					socket.close();
					frame.hide();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
			}
		});
		
		try {
			connection();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		txtChatbox = new JTextField();
		txtChatbox.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					communication();
				}
			}
		});
		panel.add(txtChatbox);
		txtChatbox.setColumns(10);
		
		JButton btnSend = new JButton("Send");
		btnSend.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				communication();
				
			}
		});
		panel.add(btnSend);
		
		
		
		txtrChatarea = new JTextArea();
		txtrChatarea.setEditable(false);
		contentPane.add(txtrChatarea, BorderLayout.CENTER);
	}
	
	

	private void communication() {
		
		try {
					sendMessage(txtChatbox.getText());
					txtrChatarea.append("==>You : "+ txtChatbox.getText()+"\n");
					txtrChatarea.append("==>Maria : "+getMessage()+"\n");
					txtChatbox.setText("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	}

	public void connection() throws UnknownHostException, IOException {
		
		socket = new Socket("127.0.0.1",Server.PORT);
		System.out.println("Client Connected...");
		out = new ObjectOutputStream(socket.getOutputStream());		
		in = new ObjectInputStream(socket.getInputStream());
		Buffreader = new BufferedReader(new InputStreamReader(System.in));
	}
	
	private void sendMessage(String message) throws IOException {

		data.setMessage(message);
		out.writeObject(data);

	}

	private String getMessage() throws ClassNotFoundException, IOException {
	
			data = (Message) in.readObject();
			System.out.println(data.getMessage());
			
			return data.getMessage();
	}
}

package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;

import TCP_Socket_Client.Message;
import TCP_Socket_Client.Server;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

public class frmMaria_interanl extends JInternalFrame {

	private JPanel contentPane;
	private JTextField txtChatbox;
	ObjectOutputStream out;
	ObjectInputStream in;
	private Socket socket;
	BufferedReader Buffreader;
	private String serverName;
	private int port;
	Message data = new Message();
	static frmMaria_interanl frame;
	
	private static Users user ;
	private static int time_id =-1;
	JTextArea txtrChatarea;
	
	static Logger log = Logger.getLogger(frmLogin.class);
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame= new frmMaria_interanl();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmMaria_interanl() {
		addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameClosing(InternalFrameEvent e) {
			CloseSocket();
			
			}
			@Override
			public void internalFrameClosed(InternalFrameEvent e) {
				CloseSocket();
			}
		});
		setBounds(100, 100, 450, 300);
		intialize();	
	}
	
	private void intialize() {

		
		
		try {
			connection();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			log.error("Client Failed to connect to Server");
			e2.printStackTrace();
			
			JOptionPane.showMessageDialog(null, "Maria has Corona, Come back later to check if she's feeling better");
			this.dispose();
		}
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		txtChatbox = new JTextField();
		txtChatbox.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					communication();
				}
			}
		});
		panel.add(txtChatbox);
		txtChatbox.setColumns(10);
		
		JButton btnSend = new JButton("Send");
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				communication();
			}
		});
		btnSend.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				communication();
				
			}
		});
		panel.add(btnSend);
		
		
		
		txtrChatarea = new JTextArea();
		txtrChatarea.setEditable(false);
		contentPane.add(txtrChatarea, BorderLayout.CENTER);
	}


	private void communication() {
		
			try {
			//	String msg = StringEscapeUtils.escapeJava(txtChatbox.getText());
				
					sendMessage(txtChatbox.getText());
				
					//sendMessage(msg);
					txtrChatarea.append("==>You : "+ txtChatbox.getText()+"\n");
					txtrChatarea.append("==>Maria : "+getMessage()+"\n");
					txtChatbox.setText("");
				} catch (IOException e1) {
					log.error("IOException thrown at the Communication block in Maria");
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					log.fatal("Class not found");
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	}

	public void connection() throws UnknownHostException, IOException {
		
		socket = new Socket("127.0.0.1",Server.PORT);
		log.info("Client Connected...");
		out = new ObjectOutputStream(socket.getOutputStream());		
		in = new ObjectInputStream(socket.getInputStream());
		Buffreader = new BufferedReader(new InputStreamReader(System.in));
	}
	
	private void sendMessage(String message) throws IOException {

		data.setMessage(message);
		out.writeObject(data);

	}

	private void CloseSocket() {
		try {
			this.socket.close();
			log.info(" Maria Client socket Closed");
		} catch (IOException e) {
			log.error("Error Closing Maria Client socket");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String getMessage() throws ClassNotFoundException, IOException {
	
			data = (Message) in.readObject();
			System.out.println(data.getMessage());
			
			return data.getMessage();
	}
}

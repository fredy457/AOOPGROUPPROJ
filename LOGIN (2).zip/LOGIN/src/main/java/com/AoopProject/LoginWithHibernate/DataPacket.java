package com.AoopProject.LoginWithHibernate;

import java.io.Serializable;

public class DataPacket implements Serializable {

	private String message;

	public DataPacket() {
		
		this.message = "";
	}
	
	public DataPacket(String message) {
		
		this.message = message;
	}

	public DataPacket(DataPacket d) {
		
		this.message = d.message;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

	@Override
	public String toString() {
		return "DataPacket [message=" + message + "]";
	}
}

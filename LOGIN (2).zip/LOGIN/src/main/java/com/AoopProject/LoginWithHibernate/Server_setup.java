package com.AoopProject.LoginWithHibernate;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.PublicKey;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Server_setup {

	
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		new Server_setup();
	
	}
	
	public Server_setup() throws IOException {
		
		ServerSocket ss = new ServerSocket(5056); 
        
        // running infinite loop for getting 
        // client request 
        while (true)  
        { 
            Socket s = null; 
              
            try 
            { 
                // socket object to receive incoming client requests 
                s = ss.accept(); 
                  
                System.out.println("A new client is connected : " + s); 
                  
                // obtaining input and out streams 
                DataInputStream dis = new DataInputStream(s.getInputStream()); 
                DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
                  
                System.out.println("Assigning new thread for this client"); 
  
                // create a new thread object 
                Thread t = new ClientHandler(s, dis, dos); 
                
                               
                // Invoking the start() method 
                t.start(); 
                  
            } 
            catch (Exception e){ 
                s.close(); 
                e.printStackTrace(); 
            } 
        } 

	}
}

//ClientHandler class 
class ClientHandler extends Thread  
{ 
 DateFormat fordate = new SimpleDateFormat("yyyy/MM/dd"); 
 DateFormat fortime = new SimpleDateFormat("hh:mm:ss"); 
 final DataInputStream dis; 
 final DataOutputStream dos; 
 final Socket s; 
   

 // Constructor 
 public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos)  
 { 
     this.s = s; 
     this.dis = dis; 
     this.dos = dos; 
 } 

 @Override
 public void run()  
 { 
	 
	 String[][] chatBot={
		     // standard greetings
		      {"hi","hello","hola","ola","hey","howdy","good morning","good day"},
		      {"what is your name?","who are you"},
		      //questions
		      {"kyle","mark","chad","dahlia"},
		      {"what position are you applying for?"},
		      {"ceo","business execuctive","manger","janitior"},
		      {"do you have the qualifications for this job?","do you have any experience with this job?"},
		      
		      {"professional thief","thief"},
		      {"What can you steal?","we are sorry we have enough thieves at edwin Allen"},
		      
		      {""},
		      {""},
		      
		      {"anything","everything","I rob banks in my spare time",},
		      {"ok in my spare time I'll call the cops","ok bye"},
		      
		      {"yes","yes i do"},
		      {"ok then mail your resume to this address;\n Waterworks\n Frankfield P.O \n Clarendon "},
		      
		      {"no","no i dont","no i don't"},
		      {"sorry but you are not qualified","thank you for your time but dont call us we'll call "},
		      
		      {"ok","ok then","kl","ok kl"},
		      {"bye"},
		      
		      {"tell me","tell me plz",},
		      {"you go first","nope","ok"},
		     //question greetings 
		      {"how are you","how r you","how r u","how are u"},
		      {"good","doing well"},
		      
		      {"i wanna kiss you","come here","sml"},
		      {"really","ok but you have to tell me what u like about me first"},
		      
		      {"y","why",},   
		      {"i just dont","forget it"},
		    //default  
		      {"shutup","you're bad","noob","stop talking",
		      "( unavailable)"}
		      
		  };
		    
	 
	 
	 
	 
     String received; 
     String toreturn; 
     
      try {
    	  
		dos.writeUTF("Hello, im maria...\nType Exit to terminate connection.");
		
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
      
      
     
      
     while (true)  
     { 
         try { 

             // Ask user what he wants 
           /*  dos.writeUTF("What do you want?[Date | Time]..\n"+ 
                         "Type Exit to terminate connection."); 
               */
        	 
        	
        	 
        	 
             // receive the answer from client 
             received = dis.readUTF(); 
               
             if(received.equals("Exit")) 
             {  
                 System.out.println("Client " + this.s + " sends exit..."); 
                 System.out.println("Closing this connection."); 
                 this.s.close(); 
                 System.out.println("Connection closed"); 
                 break; 
             } 
             
             
             dos.writeUTF("-->You:\t"+received);
             
            /* 
             received = received.trim();
             while(received.charAt(received.length()-1)=='!'||
            		received.charAt(received.length()-1)=='.'||
            		received.charAt(received.length()-1)=='?'
                     ){
            	 received= received.substring(0,received.length()-1);
             }
             received=received.trim();
            */
             
             
             byte response=0;
             /*
             0:we're searching through chatBot[][] for matches
             1:we didn't find anything in chatBot[][]
             2:we did find something in chatBot[][]
             */
              //------check for matches-------
              int j=0; //which group we are checking
              String test = null;
              while(response==0){
              
            	  if(inArray(received.toLowerCase(),chatBot[j*2])){
	                 
            		  response=2;
	                  int r = (int)Math.floor(Math.random()*chatBot[(j*2)+1].length);
	                  
	                  test = "\n-->Maria\t"+chatBot[(j*2)+1][r];
	                  
	                  dos.writeUTF(test);
	                  
	                 // dos.writeUTF("\n-->Maria\t"+chatBot[(j*2)+1][r]);
	                  
	                  //System.out.println(chatBot[(j*2)+1][r]);
	                  //
              }
              
              j++;
              
              if(j*2== chatBot.length-1 && response==0){
            	  
                  response=1;
                  
              }
           }
             
             // --------default--------------
             if(response==1){
                int r = (int)Math.floor(Math.random()*chatBot[chatBot.length-1].length);
                  dos.writeUTF("\n-->Maria\t"+chatBot[chatBot.length-1][r]);
             }
             
             
           
             
            // System.out.println(test);
             
             
             
             
             
             
             
             
             
             
             
             // creating Date object 
            // Date date = new Date(); 
               
             // write on output stream based on the 
             // answer from the client 
            /* switch (received) { 
               
                 case "Date" : 
                     toreturn = fordate.format(date); 
                     dos.writeUTF(toreturn); 
                     break; 
                       
                 case "Time" : 
                     toreturn = fortime.format(date); 
                     dos.writeUTF(toreturn); 
                     break; 
                       
                 default: 
                     dos.writeUTF("Invalid input"); 
                     break; 
             } 
             */
 
         } catch (IOException e) { 
             e.printStackTrace(); 
         } 
     } 
       
     try
     { 
         // closing resources 
         this.dis.close(); 
         this.dos.close(); 
           
     }catch(IOException e){ 
         e.printStackTrace(); 
     } 
 }

 public boolean inArray(String in,String[] str){
	 
	    boolean match =false;
	    
	    for(int i=0;i<str.length;i++){
	    	
	    if(str[i].equals(in)){
	    	
	    match=true;
	    }
	    }
	    return match;
	    }


} 
	

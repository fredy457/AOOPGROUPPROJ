package com.AoopProject.LoginWithHibernate;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.LayoutStyle.ComponentPlacement;

import TCP_Socket_Client.Assistant_Class;
import TCP_Socket_Client.Assistant_operation;

import javax.swing.JTextArea;
import javax.swing.event.ListSelectionListener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.event.ListSelectionEvent;
import javax.swing.ListSelectionModel;


public class frmViewAppointment extends JInternalFrame {
	
	static frmViewAppointment frame;
	static int id;
	ArrayList<Assistant_Class> Arraylist = new ArrayList<>();
	Assistant_operation operation;
	JTextArea txtdes;	
	JList list;
	
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	Assistant_Class AssistantData = (Assistant_Class) context.getBean("Assistant_Class");
	JLabel lblTime;
	JLabel lblDate;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new frmViewAppointment(id);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmViewAppointment(int id) {
		
		this.id = id;
		
		Initalize();

	}

	private void Initalize() {
		setBounds(100, 100, 670, 425);
		getContentPane().setLayout(null);
		
		Assistant_operation operation = new Assistant_operation();
		
		Arraylist = operation.select(id); 
	
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 658, 71);
		panel.setBackground(Color.CYAN);
		getContentPane().add(panel);
		
		JLabel lblViewAppointment = new JLabel("View Appointments");
		lblViewAppointment.setFont(new Font("Tahoma", Font.PLAIN, 50));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addGap(115)
					.addComponent(lblViewAppointment, GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE)
					.addGap(87))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(lblViewAppointment, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 71, 658, 325);
		getContentPane().add(panel_1);
		
		
		
		DefaultListModel<String> listModel = new DefaultListModel<String>();
		
		 AssistantData = new Assistant_Class();
		
		for (int i = 0; i < Arraylist.size(); i++) {
			
			AssistantData = Arraylist.get(i);
			
			listModel.addElement(AssistantData.getTitle());
		}	
			
			
			
		list = new JList(listModel);
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
				int i =	list.getSelectedIndex();
					//System.out.println(i);
					loadText(i);
	                  
				}
			}
		});
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setBounds(0, 5, 186, 324);
		
		
		
		txtdes = new JTextArea();
		txtdes.setBounds(192, 84, 466, 245);
		
		JLabel lblDateLabal = new JLabel("Date");
		lblDateLabal.setBounds(212, 22, 45, 25);
		lblDateLabal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblDate = new JLabel("");
		lblDate.setBounds(275, 24, 230, 22);
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JLabel lblTimelabel = new JLabel("Time");
		lblTimelabel.setBounds(212, 53, 57, 25);
		lblTimelabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblTime = new JLabel("");
		
		lblTime.setBounds(275, 55, 230, 22);
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panel_1.setLayout(null);
		panel_1.add(list);
		panel_1.add(txtdes);
		panel_1.add(lblTimelabel);
		panel_1.add(lblTime);
		panel_1.add(lblDateLabal);
		panel_1.add(lblDate);
	}
	
	public void loadText(int i){
		Assistant_Class Assisclass = Arraylist.get(i);
		txtdes.setText(Assisclass.getDescription());
		lblDate.setText(Assisclass.getDate());
		lblTime.setText(Assisclass.getTitle());
		
	}
	
}

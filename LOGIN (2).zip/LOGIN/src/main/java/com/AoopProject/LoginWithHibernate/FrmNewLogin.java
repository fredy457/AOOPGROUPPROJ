package com.AoopProject.LoginWithHibernate;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.apache.log4j.Appender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.annotations.Parent;

import net.bytebuddy.asm.Advice.This;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.PublicKey;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

public class FrmNewLogin extends JInternalFrame {
	
	private JTextField txtUserid;
	private JPasswordField txtpassword;
	private  Logger logger = LogManager.getLogger(FrmNewLogin.class);
	static FrmNewLogin frame;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new FrmNewLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public FrmNewLogin() {
		
		
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		BasicConfigurator.configure();
		
		JLabel lblLogIn = new JLabel("LOG IN ");
		lblLogIn.setFont(new Font("Tahoma", Font.PLAIN, 32));
		lblLogIn.setBounds(184, 22, 135, 39);
		getContentPane().add(lblLogIn);
		
		JLabel lblUserId = new JLabel("User ID#");
		lblUserId.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUserId.setBounds(69, 88, 66, 20);
		getContentPane().add(lblUserId);
		
		txtUserid = new JTextField();
		txtUserid.setColumns(10);
		txtUserid.setBounds(171, 91, 186, 30);
		getContentPane().add(txtUserid);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(171, 143, 186, 30);
		getContentPane().add(txtpassword);
		
		JLabel lblUserId_1 = new JLabel("Password");
		lblUserId_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUserId_1.setBounds(69, 143, 67, 20);
		getContentPane().add(lblUserId_1);
		
		JButton btnLog_In = new JButton("Log In");
		btnLog_In.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				System.out.println("hello World");
				
				Users u = new Users();

				
				if(txtUserid.getText().equals("")) {
					
					txtUserid.requestFocusInWindow();
					
					logger.info("user id null");
				
				}
				else if(txtpassword.getPassword().equals("")) {
				
					txtpassword.requestFocusInWindow();
					
					logger.info("password null");
				
				}
				else if((u =Operations.Logging_In( Integer.parseInt(txtUserid.getText()),String.valueOf(txtpassword.getPassword())))  != null  ) {
				
				/*u = Operations.Logging_In(Integer.parseInt(txtUserid.getText()),String.valueOf(txtpassword.getPassword()));*/
					
					
					logger.info("logged in succesful" + u.getFName() + " " + u.getLName());
					
					int time_id = Operations.AddNewTimeStamp(Integer.parseInt(txtUserid.getText()));
					
					logger.info("Time stamp created and return -:" + time_id );
					
				/*
				frmMain m = SwingUtilities.getRoot(frame).getParent();
				m.
				*/
			
					//String newValue = "a string";
					//prefs.put("firstn", u.getFName());	
					
					
					/*main.setTime_Id(12);
					main.setUser();
					main.initialize();*
					//main.initialize();
					
					System.out.println(prefs.get("firstn","na"));
					System.out.println(u.getLName());
					*/
					
					closingFrame();
					
					
				}else {
					logger.info("Invalid user");
				
				}
				
				
				
			}
			
		});
		btnLog_In.setForeground(Color.WHITE);
		btnLog_In.setFont(new Font("Script MT Bold", Font.BOLD, 32));
		btnLog_In.setBackground(new Color(207, 15, 26));
		btnLog_In.setBounds(171, 200, 167, 49);
		getContentPane().add(btnLog_In);
		

		
	}
	
	public void closingFrame() {
		this.dispose();
	}
}

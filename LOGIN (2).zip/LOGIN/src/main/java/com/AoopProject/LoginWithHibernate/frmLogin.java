package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import Maria_options.testLog;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Window;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.JFormattedTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class frmLogin extends JFrame {

	private JPanel contentPane;
	static frmLogin frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new frmLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	//private static final Logger logger = LogManager.getLogger(App.class); 
	static Logger log = Logger.getLogger(frmLogin.class);
	
	private JPasswordField txtpassword;
	private JTextField txtUserid;
	
		
	Users u = new Users();
	Admin a = new Admin();
	
	public frmLogin() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 677, 431);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblLogIn = new JLabel("LOG IN ");
		lblLogIn.setFont(new Font("Tahoma", Font.PLAIN, 32));
		
		JLabel lblUserId = new JLabel("User ID#");
		lblUserId.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JLabel lblUserId_1 = new JLabel("Password");
		lblUserId_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		
		
		
		txtpassword = new JPasswordField();
		txtpassword.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					LogIn();
				}
			}
		});
		
		JButton btnLog_In = new JButton("Submit");
		btnLog_In.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				LogIn();
			}
		});
		btnLog_In.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
			
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					LogIn();
				}
			}
			
		});
		
		
		btnLog_In.setForeground(Color.WHITE);
		btnLog_In.setFont(new Font("Script MT Bold", Font.BOLD, 32));
		btnLog_In.setBackground(new Color(207, 15, 26));
		
		txtUserid = new JTextField();
		txtUserid.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					LogIn();
				}
				
			}
		});
		txtUserid.setColumns(10);
		
		JButton btnSign_Up = new JButton("Sign Up");
		btnSign_Up.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					toSignUPfrm();
				}
			}
		});
		btnSign_Up.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				toSignUPfrm();
			}

			
		});
		btnSign_Up.setForeground(Color.WHITE);
		btnSign_Up.setFont(new Font("Script MT Bold", Font.BOLD, 24));
		btnSign_Up.setBackground(new Color(207, 15, 26));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(128)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblUserId)
									.addGap(36)
									.addComponent(txtUserid, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
									.addComponent(btnLog_In, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblUserId_1)
										.addGap(35)
										.addComponent(txtpassword, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(258)
							.addComponent(lblLogIn, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnSign_Up, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(126, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(64)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLogIn)
						.addComponent(btnSign_Up, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addGap(40)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblUserId)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addComponent(txtUserid, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))
					.addGap(22)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblUserId_1)
						.addComponent(txtpassword, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
					.addComponent(btnLog_In)
					.addGap(57))
		);
		contentPane.setLayout(gl_contentPane);
		
	
	}
	
	private void toSignUPfrm() {
		FrmSign_Up sp = new FrmSign_Up();
		setVisible(false);
		sp.show();
	}
	private void LogIn() {
	
		BasicConfigurator.configure();
		
		if(txtUserid.getText().equals("")) {
			
			txtUserid.requestFocusInWindow();
			
			log.warn("user id null");
		
		}
		else if(txtpassword.getPassword().equals("")) {
		
			txtpassword.requestFocusInWindow();
			
			log.warn("password null");
		
		}
		else if((u= Operations.Logging_In(Integer.parseInt(txtUserid.getText()),String.valueOf(txtpassword.getPassword())) ) != null  ) {
							
		int time_id = Operations.AddNewTimeStamp(Integer.parseInt(txtUserid.getText()));
			
			
			log.info("User logged in succesful\n");
			
		frmNewMenu menu = new frmNewMenu(u,time_id);
		//frmUserMenu usermenu = new frmUserMenu(u,time_id);
		JOptionPane.showMessageDialog(null, "Welcome "+u.getFName() + " "+u.getLName() );
		menu.show();
		frame.dispose();
			
			
	
		}else if((a= Operations.Admin_Logging_In(Integer.parseInt(txtUserid.getText()),String.valueOf(txtpassword.getPassword())) ) != null  ) {
			
			//int time_id = Operations.AddNewTimeStamp(Integer.parseInt(txtUserid.getText()));
			
			
			log.info("Admin logged in succesful");
			JOptionPane.showMessageDialog(null, "Welcome "+a.getFName() + " "+a.getLName() );
			frmAdminMenu menu = new frmAdminMenu(a);
			menu.show();
			frame.dispose();
			
			
			
			}else {
				JOptionPane.showMessageDialog(null, "Invalid User");
			}
	}
	
}

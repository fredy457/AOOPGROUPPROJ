package com.AoopProject.LoginWithHibernate;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import javax.swing.JTextField;
import com.toedter.calendar.JCalendar;

import TCP_Socket_Client.Maria_Convo_Options;

import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.ScrollPane;
import java.awt.Scrollbar;
import java.awt.Button;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import net.miginfocom.swing.MigLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class frmSetAppointment extends JInternalFrame {
	private JTextField txtTile;
	
	JComboBox cmbHour = new JComboBox();
	
	JCalendar calendar = new JCalendar();
	
	JComboBox cmbMinutes = new JComboBox();

	JTextArea txtrTxtdescription = new JTextArea();
	
	private static int id;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmSetAppointment frame = new frmSetAppointment(id);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmSetAppointment(int id) {
		initialize();
		this.id=id;
	}
	
	private void initialize() {
		
		
		setBounds(100, 100, 683, 548);
		
		for (int i = 1; i < 25; i++) {
			cmbHour.addItem(i);
		}
		
		for (int i = 0; i < 60; i++) {
			cmbMinutes.addItem(i);
		}
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 671, 92);
		panel.setBackground(Color.CYAN);
		
		JLabel lblSetNewAppointmat = new JLabel("Set New Appointmat");
		lblSetNewAppointmat.setFont(new Font("Tahoma", Font.PLAIN, 40));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(140)
					.addComponent(lblSetNewAppointmat, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(169))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(24)
					.addComponent(lblSetNewAppointmat, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(19))
		);
		panel.setLayout(gl_panel);
		getContentPane().add(panel);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setBounds(87, 121, 38, 25);
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(lblTitle);
		
		JLabel lblTime = new JLabel("Time");
		lblTime.setBounds(374, 146, 44, 25);
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(lblTime);
		
		JLabel lblHour = new JLabel("Hour");
		lblHour.setBounds(428, 131, 38, 13);
		getContentPane().add(lblHour);
		
		
		
		JLabel lblMinute = new JLabel("Minute");
		lblMinute.setBounds(492, 131, 44, 13);
		getContentPane().add(lblMinute);
		
		txtTile = new JTextField();
		txtTile.setBounds(33, 153, 255, 19);
		txtTile.setColumns(10);
		getContentPane().add(txtTile);
		cmbHour.setBounds(428, 156, 54, 21);
		getContentPane().add(cmbHour);
		cmbMinutes.setBounds(492, 156, 54, 21);
		getContentPane().add(cmbMinutes);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setBounds(453, 206, 41, 25);
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(lblDate);
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setBounds(10, 252, 314, 122);
		//
		
		JLabel lblDescrip = new JLabel("Description");
		lblDescrip.setBounds(68, 206, 99, 25);
		lblDescrip.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(lblDescrip);
		calendar.setBounds(387, 236, 206, 152);
		getContentPane().add(calendar);
		
		txtrTxtdescription.setBounds(33, 229, 255, 159);
		txtrTxtdescription.setRows(2);
		txtrTxtdescription.setColumns(8);
		txtrTxtdescription.setLineWrap(true);
		txtrTxtdescription.setWrapStyleWord(true);
		scrollPane.add(txtrTxtdescription);
		getContentPane().add(scrollPane);
		
		
		
		//getContentPane().add(txtrTxtdescription);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(199, 391, 89, 31);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Upload();
			}
		});
		
		
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		getContentPane().add(btnSubmit);

	}
	

	public void Upload() {
		
		if(txtTile.getText() != "") {
		
		int hour = Integer.parseInt(cmbHour.getSelectedItem().toString());
		int minute = Integer.parseInt(cmbMinutes.getSelectedItem().toString());
		
		Time time = new Time(hour, minute, 0);
		System.out.println(" Time " + time);
		System.out.println("original date "+calendar.getDate());
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String newDate = dateFormat.format(calendar.getDate());
		System.out.println("new Date "+newDate);
		
			
			try {
				Maria_Convo_Options.UploadAppointment(txtTile.getText(),id,txtrTxtdescription.getText(),newDate,time);
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
	}
}


package com.AoopProject.LoginWithHibernate;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="admin")
public class Admin implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="UserId",unique=true)
	private int id;
	
	@Column(name="FirstName",nullable=false)
	private String FName;
	
	@Column(name="LastName",nullable=false)
	private String LName;
	
	@Column(name="Gender",nullable=false)
	private String Gender;
	
	@Column(name="Department",nullable=false)
	private String Dment;
	
	@Column(name="TelephoneNumber",nullable=false)
	private String Number;
	
	@Column(name="Email",nullable=false)
	private String Email;
	
	@Column(name="HashedPassword",nullable=false)
	private String Pword;
	
	
	
	public int getId() {
		return id;
	}
	
	public Admin() {
		
		FName = "";
		LName = "";
		Dment = "";
		Number = "";
		Email = "";
		Pword = "";
	}
	
	public Admin(String fName, String lName,String gender, String dment, String number, String email, String pword) {
		
		
		FName = fName;
		LName = lName;
		Gender = gender;
		Dment = dment;
		Number = number;
		Email = email;
		Pword = pword;
	}
	
	
	
	public Admin(int id, String fName, String lName, String dment, String email) {
		
		this.id = id;
		FName = fName;
		LName = lName;
		Dment = dment;
		Email = email;
	}

	public void SetId(int id) {
		this.id=id;
	}
	public String getFName() {
		return FName;
	}
	
	public String getLName() {
		return LName;
	}
	
	public String getDment() {
		return Dment;
	}
	public String getNumber() {
		return Number;
	}
	
	public String getPword() {
		return Pword;
	}
	
	public void SetFName(String FName) {
		this.FName=FName;
	}
	public void SetLName(String LName) {
		this.LName=LName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}

	public void SetDment(String Dment) {
		this.Dment=Dment;
	}
	public void SetNumber(String Number) {
		this.Number=Number;
	}
	public void setPword(String pword) {
		Pword = pword;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	

}

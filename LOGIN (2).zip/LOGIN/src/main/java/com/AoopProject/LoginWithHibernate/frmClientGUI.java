package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmClientGUI extends JFrame {

	static Socket sckt;  
	static DataInputStream dtinpt;  
    static DataOutputStream dtotpt; 
	
	
	private JPanel contentPane;
	private JTextField txtMsg;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmClientGUI frame = new frmClientGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		/*
		try {  
			   sckt = new Socket("127.0.0.1", 1201);  
			   dtinpt = new DataInputStream(sckt.getInputStream());  
			   dtotpt = new DataOutputStream(sckt.getOutputStream());  
			   String msgin = "";  
			   
			   while (!msgin.equals("Exit")) {  
			    msgin = dtinpt.readUTF();  
			    jTextArea1.setText(jTextArea1.getText().trim() + "\n Server:" + msgin);  
			   }
			   
			  } catch (Exception e) {} 
		*/
	}

	/**
	 * Create the frame.
	 */
	public frmClientGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 385);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 10, 571, 260);
		contentPane.add(textArea);
		
		txtMsg = new JTextField();
		txtMsg.setBounds(20, 296, 458, 33);
		contentPane.add(txtMsg);
		txtMsg.setColumns(10);
		
		JButton btnSend = new JButton("Send");
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSend.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSend.setBounds(496, 296, 85, 33);
		contentPane.add(btnSend);
	}

}

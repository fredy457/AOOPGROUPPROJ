package com.AoopProject.LoginWithHibernate;

public class testing_method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Operations.GetAllDeparmentId();
		
	}

}

package com.AoopProject.LoginWithHibernate;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@Entity
@Table(name="timesheet")
public class TimeSheet implements Serializable{
	
	private static final long serialVersionUID = 2L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idTimeSheet",unique=true)
	private int time_id;
	
	@Column(name="Date",nullable = true)
	private Date date;
	
	@Column(name="Arrival",nullable = true)
	private int arrival;
	
	@Column(name="Departure",nullable = true)
	private int departure;
	
	@Generated(GenerationTime.ALWAYS) 
	@Column(name="Hours",insertable=false,updatable=false)
	private int hours;
	
	//the user id 
	
	@Column(name = "userId")
	private int user_id;
	
	/*
	private Users user;
	
	@ManyToOne
	@JoinColumn(name = "UserId")
	public Users getUsers() {
	    return user;
	}*/
	
	
	public TimeSheet( ) {
		
		
	}
	
	public TimeSheet( Date date, int arrival, int departure, int hours,int user_id) {
		
		
		this.date = date;
		this.arrival = arrival;
		this.departure = departure;
		this.hours = hours;
		this.user_id = user_id;
		//this.user = user;
	}

	public int getTime_id() {
		return time_id;
	}

	public void setTime_id(int time_id) {
		this.time_id = time_id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getArrival() {
		return arrival;
	}

	public void setArrival(int arrival) {
		this.arrival = arrival;
	}

	public int getDeparture() {
		return departure;
	}

	public void setDeparture(int departure) {
		this.departure = departure;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
	
	
	/*
	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
	*/
	
}

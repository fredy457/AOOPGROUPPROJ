package com.AoopProject.LoginWithHibernate;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;



public class UsersOp {
	
	private static EntityManagerFactory ENTITY_MANAGER_FACTORY= Persistence.createEntityManagerFactory("LOGIN");
	
	private static final Logger logger = LogManager.getLogger(App.class); 

	public void basicConfig() {
		BasicConfigurator.configure();
	}
	
	
	public static void AddUser(int Id,String LName, String FName,String Dment,String Number) {
		
		
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		Users user=new Users();
		
		try {
			ET=EM.getTransaction();
			ET.begin();
			logger.info("Transaction has begin");
			
			user.SetId(Id);
			user.SetDment(Dment);
			user.SetFName(FName);
			user.SetLName(LName);
			user.SetNumber(Number);	
			EM.persist(user);
			ET.commit();
			logger.info("Committing to database");
			
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
				logger.info("Transaction has roll back");
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Adding Method Finish*/}
	
	public static void GetSingleUser(int Id) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String query="SELECT u FROM Users u WHERE u.Id=:UserId";
		
		TypedQuery<Users> TQ=EM.createQuery(query,Users.class);
		TQ.setParameter("UserId",Id);
		Users user=null;
		try {
			user=TQ.getSingleResult();
			System.out.println(user.getLName()+" "+user.getLName());
		} catch (NoResultException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		
		}
		finally {
			EM.close();
		}
	/*GETTING INDIVIDUAL USER FROM DATABASE*/}
	
	public static void GetMultipleUser(int Id) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String SQuery= "SELECT u FROM Users WHERE u.Id IS NOT NULL"; 
		TypedQuery<Users> TQ=EM.createQuery(SQuery,Users.class);
		List<Users>users;
		try {
			users=TQ.getResultList();
			users.forEach(user->System.out.println(user.getFName()+" "+ user.getLName()));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			EM.close();
		}
		finally {
			EM.close();
		}
	/*GETTING ALL USERS FROM DATABASE*/}
	
	public static void UpdateUser(int Id,String LName, String FName,String Dment,String Number) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		Users user=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			user=EM.find(Users.class, Id);
			user.SetDment(Dment);
			user.SetFName(FName);
			user.SetLName(LName);
			user.SetNumber(Number);
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Updating Method Finish*/}
	
	public static void DeleteUser(int Id) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		Users user=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			user=EM.find(Users.class, Id);
			EM.remove(user);
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Updating Method Finish*/}
	
	
	
	public static Users Logging_in(int Id,String pass) {
		
		/*Checking DATABASE for a user that's already registered*/
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String query="SELECT u FROM Users u WHERE u.id=:UserId and u.Pword =:Hpass";
		
		TypedQuery<Users> TQ=EM.createQuery(query,Users.class);
		TQ.setParameter("UserId",Id);
		try {
			TQ.setParameter("Hpass",toHexString(getSHA(pass)));
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Users user=null;
		try {
			user=TQ.getSingleResult();
			System.out.println(user.getFName()+" "+user.getLName());
		} catch (NoResultException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		
		}
		finally {
			EM.close();
		}
	
		return user;
		}
	
	public static void AddUser(int Id,String LName, String FName,String Dment,String Number,String pword) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			
			Users user=new Users();
			//user.SetId(Id);
			user.SetDment(Dment);
			user.SetFName(FName);
			user.SetLName(LName);
			user.SetNumber(Number);
			
			user.setPword(toHexString(getSHA(pword)) );
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Adding Method Finish*/}
	

	public static byte[] getSHA(String text) throws NoSuchAlgorithmException {
		
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		
		return	messageDigest.digest(text.getBytes(StandardCharsets.UTF_8));
		
	}
	
	
	public static String toHexString(byte[] hash) {
		
		BigInteger number = new BigInteger(1, hash);
		
		StringBuilder hexString = new StringBuilder(number.toString(16));
		
		while(hexString.length() < 32) {
			hexString.insert(0, '0');
		}
		
		return hexString.toString();
	}
	
	
	
}

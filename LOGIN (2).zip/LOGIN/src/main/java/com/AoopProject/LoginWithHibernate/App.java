package com.AoopProject.LoginWithHibernate;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hibernate.type.LocalDateType;

public class App {
	private static EntityManagerFactory ENTITY_MANAGER_FACTORY= Persistence.createEntityManagerFactory("LOGIN");
	
	public static void main( String[] args ) throws NoSuchAlgorithmException{
        
		AddUser(5,"Bailey","Frost","Sales","18764592384","testing123");
		
		//GetSingleUser(1);
		/*
		String h = "testing";
		System.out.println("orignal text : " + h +"\nHashed text : " + toHexString(getSHA(h)) );
		*/
		
		/*
		UsersOp op = new UsersOp();
		
		op.AddUser(0, "Bailey", "Cold", "ICT", "15487954", "Testing123");
		
		*/
		
		/*DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	    Date date = new Date();
	    System.out.println(dateFormat.format(date));
		*/
		ENTITY_MANAGER_FACTORY.close();
    }
	
	
	
	public static byte[] getSHA(String text) throws NoSuchAlgorithmException {
		
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		
		return	messageDigest.digest(text.getBytes(StandardCharsets.UTF_8));
		
	}
	
	
	public static String toHexString(byte[] hash) {
		
		BigInteger number = new BigInteger(1, hash);
		
		StringBuilder hexString = new StringBuilder(number.toString(16));
		
		while(hexString.length() < 32) {
			hexString.insert(0, '0');
		}
		
		return hexString.toString();
	}
	
	
	
	
	
	
	
	public static void AddUser(int Id,String LName, String FName,String Dment,String Number,String pword) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			
			Users user=new Users();
			user.SetId(Id);
			user.SetDment(Dment);
			user.SetFName(FName);
			user.SetLName(LName);
			user.SetNumber(Number);
			user.setPword(pword);
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Adding Method Finish*/}
	
		
	public static void GetSingleUser(int Id) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String query="SELECT u FROM Users u WHERE u.id = :UserId";
		
		TypedQuery<Users> TQ=EM.createQuery(query,Users.class);
		TQ.setParameter("UserId",Id);
		Users user=null;
		try {
			user=TQ.getSingleResult();
			System.out.println(user.getFName()+" "+user.getLName());
		} catch (NoResultException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		
		}
		finally {
			EM.close();
		}
	/*GETTING INDIVIDUAL USER FROM DATABASE*/
		}
	
	public static void GetMultipleUser() {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		
		String SQuery= "SELECT u FROM Users WHERE u.Id IS NOT NULL"; 
		
		TypedQuery<Users> TQ=EM.createQuery(SQuery,Users.class);
		
		List<Users>users;
		
		try {
			users=TQ.getResultList();
			users.forEach(user->System.out.println(user.getFName()+" "+ user.getLName()));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			EM.close();
		}
		finally {
			EM.close();
		}
	/*GETTING ALL USERS FROM DATABASE*/}
	
	public static void UpdateUser(int Id,String LName, String FName,String Dment,String Number) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		Users user=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			user=EM.find(Users.class, Id);
			user.SetDment(Dment);
			user.SetFName(FName);
			user.SetLName(LName);
			user.SetNumber(Number);
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Updating Method Finish*/}
	
	public static void DeleteUser(int Id) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		Users user=null;
		try {
			ET=EM.getTransaction();
			ET.begin();
			user=EM.find(Users.class, Id);
			EM.remove(user);
			EM.persist(user);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	/*Updating Method Finish*/}
	
	
}

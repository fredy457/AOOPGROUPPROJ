package com.AoopProject.LoginWithHibernate;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Operations {

private static EntityManagerFactory ENTITY_MANAGER_FACTORY= Persistence.createEntityManagerFactory("LOGIN");
	
	//private static final Logger logger = LogManager.getLogger(App.class); 
	static Logger log = Logger.getLogger(Operations.class);
	
	public void basicConfig() {
		BasicConfigurator.configure();
	}
	
	
	//ADDING A NEW USER TO THE DATABASE
		public static int AddNewUser( String FName,String LName,String gender,String Dment,String Number,String email ,String pword) {
			EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
			EntityTransaction ET=null;
			int id= 0;
			
			try {
				ET=EM.getTransaction();
				ET.begin();
				log.info("Transaction as begon");
				
				Users user=new Users(FName,LName,gender,Dment,Number,email,toHexString(getSHA(pword)));
				
				EM.persist(user);
				
				ET.commit();
				
				
				log.info("Committing complete");
				
				//System.out.println();
				id = user.getId();
				
			} catch (Exception e) {
				// TODO: handle exception
				log.error("Error Adding New User");
				if(ET!=null) {
					ET.rollback();
					log.warn("Entity Transaction has rolled back");
				}
				e.printStackTrace();
			}
			finally {
				EM.close();
				log.info("Entity Manager has Close");
			}
			
			log.info("Returning User Id");
			return id;
			
		/*Adding Method Finish*/
			
		}
		
	
	
	
	//ADDING TIME STAMP TO THE DATABASE
	public static int AddNewTimeStamp(int userid) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		TimeSheet time = new TimeSheet();
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	    Date date = new Date();
	    //System.out.println(dateFormat.format(date));
		
		
		int T_id = 0;
		try {
			ET=EM.getTransaction();
			ET.begin();
			log.info("Transaction as begon");
			
			
			
			time.setUser_id(userid);
			time.setDate(date);
			time.setArrival(date.getHours());
			time.setHours(0);
			
			
			
			
			EM.persist(time);
			
			ET.commit();
			log.info("Committing complete - new time stamp created ");
			
			T_id = time.getTime_id(); 
			
		} catch (Exception e) {
			
			log.error("Error Adding Time Stamp");
			
			if(ET!=null) {
				ET.rollback();
				log.error("Entity Transaction has rolled back");
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
			log.info("Entity Manager has Close");
		 }
		log.info("Returning Time Id");
		return T_id;
		/*Adding Method Finish*/
		
	}
	
	
	/* GETTING INDIVIDUAL USER FROM DATABASE */
	public static Users Logging_In(int Id,String Hashpwd) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String query="SELECT u FROM Users u WHERE u.id = :UserId and u.Pword =:HashedPassword";
		
		Users user=null;
		
		try {
		TypedQuery<Users> TQ=EM.createQuery(query,Users.class);
		TQ.setParameter("UserId",Id);
		TQ.setParameter("HashedPassword", toHexString(getSHA(Hashpwd)));
		
		
			user=TQ.getSingleResult();
			log.info("User recieved");
			//System.out.println(user.getFName()+" "+user.getLName());
			
		} catch (NoResultException ex) {
			
			log.error("Error Executing Logging in sql-  No Result found");
			ex.printStackTrace();
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			EM.close();
			log.info("Entity Manager has Close");
		}
		
		return user;
		
		}
	
	/* GETTING INDIVIDUAL USER FROM DATABASE */
	public static Admin Admin_Logging_In(int Id,String Hashpwd) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String query="SELECT a FROM Admin a WHERE a.id = :UserId and a.Pword =:HashedPassword";
		
	Admin a =null;
		
		try {
		TypedQuery<Admin> TQ=EM.createQuery(query,Admin.class);
		TQ.setParameter("UserId",Id);
		TQ.setParameter("HashedPassword", toHexString(getSHA(Hashpwd)));
		
		
			a=TQ.getSingleResult();
			
			//System.out.println(user.getFName()+" "+user.getLName());
			
		} catch (NoResultException ex) {
			// TODO: handle exception
			log.error("Error Executing Logging in sql-  No Result found");
			ex.printStackTrace();
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			EM.close();
			log.info("Entity Manager has Close");
		}
		log.info("Returning Admin");
		return a;
		
		}
	
	
	/* GETTING INDIVIDUAL USER FROM DATABASE */
	public static void updateTimeStamp(int id) {
		
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		TimeSheet t=null;
		Date date = new Date();
		
		try {
			ET=EM.getTransaction();
			ET.begin();
			log.info("Transaction has begun");
			t=EM.find(TimeSheet.class, id);
			t.setDeparture(date.getHours());
			
			EM.persist(t);
			log.info("update Persistance set");
			ET.commit();
			log.info("Commit Completed Sucessful");
		} catch (Exception e) {
			log.error("Error - Uncertain Exception thrown");
			if(ET!=null) {
				log.warn("Rolling Back Changes");
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			
			EM.close();
			log.warn("Entity Manager has close");
		 }
	
		
		}
	
	public static void updat(int id, int id_u) {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		EntityTransaction ET=null;
		TimeSheet t=null;
		Date date = new Date();
		
		try {
			ET=EM.getTransaction();
			ET.begin();
			t=EM.find(TimeSheet.class, id);
			t.setDeparture(date.getHours());
			
			EM.persist(t);
			ET.commit();
		} catch (Exception e) {
			// TODO: handle exception
			if(ET!=null) {
				ET.rollback();
			}
			e.printStackTrace();
		}
		finally {
			EM.close();
		 }
	}
	
	/*Department Id*/
	public static List<Department> GetAllDeparmentId() {
		EntityManager EM=ENTITY_MANAGER_FACTORY.createEntityManager();
		String SQuery= "SELECT d FROM Department d WHERE d.id IS NOT NULL"; 
		TypedQuery<Department> TQ=EM.createQuery(SQuery,Department.class);
		List<Department>depart = null;
		
		try {
			depart=TQ.getResultList();
			depart.forEach(Depart->System.out.println(Depart.getDepart_id()+" "+ Depart.getDepart_Name()));
			log.info("Department Received");
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Unexpectd error when receiving Department");
			e.printStackTrace();
			
		}
		finally {
			EM.close();
			log.info("Entity Manager has Close");
		}
		
		log.info("Returning Department");
		return depart;
	}
	
	
	
	
	/*
	 HASHING METHODS BELOW	  
	 */

	public static byte[] getSHA(String text) throws NoSuchAlgorithmException {
		
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		
		return	messageDigest.digest(text.getBytes(StandardCharsets.UTF_8));
		
	}
	
	
	public static String toHexString(byte[] hash) {
		
		BigInteger number = new BigInteger(1, hash);
		
		StringBuilder hexString = new StringBuilder(number.toString(16));
		
		while(hexString.length() < 32) {
			hexString.insert(0, '0');
		}
		
		return hexString.toString();
	}
	
	
	
}

package com.AoopProject.LoginWithHibernate;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JButton;
import java.awt.Font;
import java.text.ParseException;
import java.util.List;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JFormattedTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Canvas;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrmSign_Up extends JFrame {

	private JPanel contentPane;
	private JTextField txtFname;
	private JTextField txtLname;
	private JPasswordField txtPassword;
	private JPasswordField txtConfrimPassword;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmSign_Up frame = new FrmSign_Up();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmSign_Up() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1058, 619);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(191, 188, 188));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(61,4,8));
		panel.setForeground(Color.WHITE);
		panel.setBounds(0, 0, 482, 582);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(-81, 219, 0, 0);
		panel.add(label_1);
		
		JLabel lblDigitalAssitant = new JLabel("Digital \r\nAssitant");
		lblDigitalAssitant.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 39));
		lblDigitalAssitant.setForeground(new Color(255, 255, 255));
		lblDigitalAssitant.setBounds(38, 195, 288, 96);
		panel.add(lblDigitalAssitant);
		
			
		JLabel lblNewLabel = new JLabel("First Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(502, 37, 77, 20);
		contentPane.add(lblNewLabel);
		
		txtFname = new JTextField();
		txtFname.setFont(new Font("Arial", Font.BOLD, 16));
		txtFname.setColumns(10);
		txtFname.setBounds(512, 67, 200, 30);
		contentPane.add(txtFname);
		
		JLabel lblNewLabel_1 = new JLabel("Last Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(765, 37, 76, 20);
		contentPane.add(lblNewLabel_1);
		
		txtLname = new JTextField();
		txtLname.setFont(new Font("Arial", Font.BOLD, 16));
		txtLname.setColumns(10);
		txtLname.setBounds(775, 67, 206, 30);
		contentPane.add(txtLname);
		
		JLabel lblDepartment = new JLabel("Department");
		lblDepartment.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDepartment.setBounds(502, 119, 86, 20);
		contentPane.add(lblDepartment);
		
		JLabel lblTelephoneNumber = new JLabel("Telephone Number");
		lblTelephoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTelephoneNumber.setBounds(502, 226, 136, 20);
		contentPane.add(lblTelephoneNumber);
		
		MaskFormatter mask = null;
		
		try {
			mask = new MaskFormatter("(###) ###-####");
			mask.setPlaceholderCharacter('_');
		}catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		JFormattedTextField txtTele = new JFormattedTextField(mask);
		txtTele.setFont(new Font("Arial", Font.BOLD, 16));
		txtTele.setBounds(512, 267, 168, 30);
		contentPane.add(txtTele);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPassword.setBounds(502, 335, 67, 20);
		contentPane.add(lblPassword);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Arial", Font.BOLD, 16));
		txtPassword.setColumns(18);
		txtPassword.setBounds(512, 365, 200, 30);
		contentPane.add(txtPassword);
		
		JLabel lblConfirmPassword = new JLabel("Confirm Password");
		lblConfirmPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblConfirmPassword.setBounds(739, 335, 136, 20);
		contentPane.add(lblConfirmPassword);
		
		txtConfrimPassword = new JPasswordField();
		txtConfrimPassword.setFont(new Font("Arial", Font.BOLD, 16));
		txtConfrimPassword.setBounds(775, 365, 216, 30);
		contentPane.add(txtConfrimPassword);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEmail.setBounds(753, 226, 136, 20);
		contentPane.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(775, 269, 206, 30);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		JButton btnLog_In = new JButton("Log In");
		btnLog_In.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmLogin login = new frmLogin();
				login.setVisible(true);
				setVisible(false);
						
			}
		});
		btnLog_In.setForeground(Color.WHITE);
		btnLog_In.setFont(new Font("Script MT Bold", Font.BOLD, 32));
		btnLog_In.setBackground(new Color(207, 15, 26));
		btnLog_In.setBounds(767, 477, 214, 47);
		contentPane.add(btnLog_In);
		
		
		List<Department> dList = null;
		
		try {
			dList = Operations.GetAllDeparmentId();
		} catch (Exception e2) {
			// TODO: handle exception
		}
		
		JComboBox cmbDepart = new JComboBox();
		
		for (Department department : dList) {
			cmbDepart.addItem(department.getDepart_id());
		}
		cmbDepart.setBounds(512, 149, 204, 30);
		contentPane.add(cmbDepart);
		
		JRadioButton rdbtnfemale = new JRadioButton("Female");
		rdbtnfemale.setSelected(true);
		rdbtnfemale.setFont(new Font("Tahoma", Font.PLAIN, 16));
		rdbtnfemale.setBackground(Color.LIGHT_GRAY);
		rdbtnfemale.setBounds(772, 152, 103, 21);
		rdbtnfemale.setActionCommand("Female");
		contentPane.add(rdbtnfemale);
		
		JRadioButton rdbtnMale = new JRadioButton("Male");
		rdbtnMale.setFont(new Font("Tahoma", Font.PLAIN, 16));
		rdbtnMale.setBackground(Color.LIGHT_GRAY);
		rdbtnMale.setBounds(892, 152, 103, 21);
		rdbtnMale.setActionCommand("Male");
		contentPane.add(rdbtnMale);
		
		ButtonGroup btngroup = new ButtonGroup();
		
		btngroup.add(rdbtnMale);
		btngroup.add(rdbtnfemale);
		
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblGender.setBounds(765, 123, 77, 13);
		contentPane.add(lblGender);
		
		JButton btnSignUp = new JButton("Sign UP");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				//String s ="";
				
				///if()
				
				
				Operations operation = new Operations();
			
				if(txtFname.getText().equals("")) {
					
					txtFname.requestFocusInWindow();
					
				}else if(txtLname.getText().equals("")) {
					
					txtLname.requestFocusInWindow();
					
				}else if(txtTele.getText() == null) {
					
					txtTele.requestFocusInWindow();
					
				}else if(txtPassword.getPassword().equals("")) {
					
					txtPassword.requestFocusInWindow();
			
				}else if(txtPassword.getText().length() < 8){
				
					txtPassword.requestFocusInWindow();
					
				} else if(txtConfrimPassword.getPassword().equals("")) {
					
					txtConfrimPassword.requestFocusInWindow();
				
				}else {
					
					
					
					
			int id = operation.AddNewUser(txtFname.getText(), txtLname.getText(),btngroup.getSelection().getActionCommand(),cmbDepart.getSelectedItem().toString(),txtTele.getText(),txtEmail.getText(),txtConfrimPassword.getText());                                    
					
			JOptionPane.showMessageDialog(null,"Welcome "+  txtFname.getText() +" "+ txtLname.getText() +", You User Id number is :  " + id  ,"Welcom New User",JOptionPane.INFORMATION_MESSAGE);
				
			frmLogin login = new frmLogin();
			login.setVisible(true);
			setVisible(false);
			
			
				}
				
				
			}
		});
		btnSignUp.setBackground(new Color(207, 15, 26));
		btnSignUp.setForeground(Color.WHITE);
		btnSignUp.setFont(new Font("Script MT Bold", Font.BOLD, 32));
		btnSignUp.setBounds(502, 477, 214, 47);
		contentPane.add(btnSignUp);
		
	}
}

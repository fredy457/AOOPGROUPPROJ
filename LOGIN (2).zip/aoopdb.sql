-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2020 at 03:43 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aoopdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `TelephoneNumber` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `HashedPassword` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`UserId`, `FirstName`, `LastName`, `Gender`, `Department`, `TelephoneNumber`, `Email`, `HashedPassword`) VALUES
(1, 'Admin', 'Zeus', 'Male', 'ICT', '(489) 651-9865', 'hello', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32');

-- --------------------------------------------------------

--
-- Table structure for table `appointmentdb`
--

CREATE TABLE `appointmentdb` (
  `idappointmentDb` int(11) NOT NULL,
  `UserId` int(11) DEFAULT NULL,
  `Title` varchar(75) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Time` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointmentdb`
--

INSERT INTO `appointmentdb` (`idappointmentDb`, `UserId`, `Title`, `Description`, `Date`, `Time`) VALUES
(1, 10, 'New', '', '0000-00-00', '03:04:00'),
(2, 10, 'New test', '', '1969-12-31', '03:04:00'),
(3, 10, 'test', 'remeber to try fix the client to client chat', '2020-12-16', '05:05:00'),
(4, 10, 'Sleep', 'Remember to sleep when you reach home', '2021-12-14', '05:30:00'),
(5, 10, 'skl project', 'presentation', '2020-12-14', '13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `conversation_category`
--

CREATE TABLE `conversation_category` (
  `categoryId` int(11) NOT NULL,
  `category_name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `conversation_category`
--

INSERT INTO `conversation_category` (`categoryId`, `category_name`) VALUES
(1, 'standard greeting'),
(2, 'Invalid'),
(3, 'Error'),
(4, 'times'),
(6, 'Small Talk 1');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Department_Id` varchar(10) NOT NULL,
  `Department_Name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Department_Id`, `Department_Name`) VALUES
('CA', 'Central Administrator'),
('DBT', 'Drafting and Building Technology'),
('ICT', 'Information Communication and Technology'),
('STR', 'Student Registery');

-- --------------------------------------------------------

--
-- Table structure for table `maria_convo_keyword`
--

CREATE TABLE `maria_convo_keyword` (
  `idmaria_convo` int(11) NOT NULL,
  `keyword` longtext NOT NULL,
  `categoryid` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maria_convo_keyword`
--

INSERT INTO `maria_convo_keyword` (`idmaria_convo`, `keyword`, `categoryid`) VALUES
(2, 'hi', 1),
(4, 'hey', 1),
(7, 'Unknown Statement... Could You Please Rephrase That', 2),
(8, 'Unknown Statement... Could You Please Rephrase That', 2),
(9, 'Hello', 1),
(10, 'what\'s up', 1),
(11, 'what time is it', 4),
(12, 'the sun is shining', 6);

-- --------------------------------------------------------

--
-- Table structure for table `maria_convo_response`
--

CREATE TABLE `maria_convo_response` (
  `idmaria_convo` int(11) NOT NULL,
  `response` longtext NOT NULL,
  `categoryid` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maria_convo_response`
--

INSERT INTO `maria_convo_response` (`idmaria_convo`, `response`, `categoryid`) VALUES
(1, 'hello, what is going on', 1),
(2, 'hola', 1),
(3, 'ola', 1),
(4, 'hey', 1),
(5, 'howdy', 1),
(7, 'good day, Are you doing well', 1),
(8, 'hi, how can i help', 1),
(9, 'invalid', 2),
(10, 'Unknown Statement... Could You Please Rephrase That', 3),
(11, 'Hi i am Maria...it is nice to meet you', 1),
(12, 'good morning', 1),
(13, 'hey, how may i help', 1),
(14, 'The time is it', 3),
(15, 'yes it is', 6);

-- --------------------------------------------------------

--
-- Table structure for table `timesheet`
--

CREATE TABLE `timesheet` (
  `idTimeSheet` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `Date` date DEFAULT NULL,
  `Arrival` int(11) DEFAULT NULL,
  `Departure` int(11) DEFAULT 0,
  `Hours` int(11) GENERATED ALWAYS AS (`Departure` - `Arrival`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timesheet`
--

INSERT INTO `timesheet` (`idTimeSheet`, `userId`, `Date`, `Arrival`, `Departure`) VALUES
(1, 6, '2020-11-19', 14, 20),
(2, 10, '2020-11-19', 15, 0),
(3, 10, '2020-12-03', 0, 13),
(4, 10, '2020-12-03', 1, 13),
(5, 10, '2020-12-03', 1, 0),
(6, 10, '2020-12-03', 1, 0),
(7, 10, '2020-12-03', 11, 0),
(8, 10, '2020-12-03', 11, 0),
(9, 10, '2020-12-03', 11, 0),
(10, 10, '2020-12-03', 11, 0),
(11, 10, '2020-12-03', 11, 0),
(12, 10, '2020-12-03', 11, 0),
(13, 10, '2020-12-03', 11, 0),
(14, 10, '2020-12-03', 11, 0),
(15, 10, '2020-12-03', 11, 0),
(16, 10, '2020-12-03', 11, 0),
(17, 10, '2020-12-03', 11, 0),
(18, 10, '2020-12-03', 11, 0),
(19, 10, '2020-12-03', 11, 0),
(20, 10, '2020-12-03', 11, 0),
(21, 10, '2020-12-03', 11, 0),
(22, 10, '2020-12-03', 11, 0),
(23, 10, '2020-12-03', 13, 0),
(24, 10, '2020-12-03', 16, 0),
(25, 10, '2020-12-03', 16, 0),
(26, 9, '2020-12-03', 16, 0),
(27, 10, '2020-12-03', 16, 0),
(28, 9, '2020-12-03', 16, 0),
(29, 9, '2020-12-03', 16, 0),
(30, 10, '2020-12-03', 16, 0),
(31, 9, '2020-12-03', 16, 0),
(32, 10, '2020-12-04', 9, 0),
(33, 10, '2020-12-04', 9, 0),
(34, 10, '2020-12-04', 9, 0),
(35, 10, '2020-12-04', 9, 0),
(36, 10, '2020-12-04', 9, 0),
(37, 10, '2020-12-04', 10, 0),
(38, 10, '2020-12-04', 10, 0),
(39, 10, '2020-12-04', 10, 0),
(40, 10, '2020-12-04', 10, 0),
(41, 10, '2020-12-04', 10, 0),
(42, 10, '2020-12-04', 10, 0),
(43, 10, '2020-12-04', 10, 0),
(44, 10, '2020-12-08', 16, 0),
(45, 10, '2020-12-08', 16, 0),
(46, 10, '2020-12-09', 2, 0),
(47, 10, '2020-12-09', 2, 0),
(48, 10, '2020-12-09', 2, 0),
(49, 10, '2020-12-09', 2, 0),
(50, 10, '2020-12-09', 2, 0),
(51, 10, '2020-12-09', 3, 0),
(52, 1, '2020-12-09', 3, 0),
(53, 10, '2020-12-09', 3, 0),
(54, 10, '2020-12-09', 3, 0),
(55, 10, '2020-12-09', 3, 0),
(56, 10, '2020-12-09', 3, 0),
(57, 10, '2020-12-09', 3, 0),
(58, 10, '2020-12-09', 3, 0),
(59, 10, '2020-12-09', 3, 0),
(60, 10, '2020-12-09', 3, 0),
(61, 10, '2020-12-09', 4, 0),
(62, 10, '2020-12-09', 12, 0),
(63, 10, '2020-12-09', 12, 0),
(64, 10, '2020-12-09', 13, 0),
(65, 10, '2020-12-09', 14, 14),
(66, 10, '2020-12-09', 15, 15),
(67, 10, '2020-12-10', 11, 11),
(68, 10, '2020-12-10', 11, 13),
(69, 10, '2020-12-10', 13, 13),
(70, 10, '2020-12-10', 14, 14),
(71, 10, '2020-12-10', 15, 0),
(72, 10, '2020-12-10', 15, 0),
(73, 10, '2020-12-10', 16, 16),
(74, 10, '2020-12-10', 16, 16),
(75, 10, '2020-12-10', 16, 16),
(76, 10, '2020-12-10', 16, 16),
(77, 10, '2020-12-10', 16, 16),
(78, 10, '2020-12-10', 16, 16),
(79, 10, '2020-12-10', 16, 16),
(80, 10, '2020-12-10', 16, 16),
(81, 10, '2020-12-10', 16, 16),
(82, 10, '2020-12-10', 17, 0),
(83, 10, '2020-12-10', 17, 18),
(84, 10, '2020-12-10', 18, 18),
(85, 10, '2020-12-10', 22, 22),
(86, 10, '2020-12-10', 22, 0),
(87, 10, '2020-12-10', 22, 22),
(88, 10, '2020-12-10', 22, 22),
(89, 10, '2020-12-10', 22, 23),
(90, 10, '2020-12-10', 22, 0),
(91, 10, '2020-12-10', 22, 23),
(92, 10, '2020-12-10', 23, 23),
(93, 10, '2020-12-10', 23, 23),
(94, 10, '2020-12-10', 23, 23),
(95, 10, '2020-12-10', 23, 23),
(96, 10, '2020-12-10', 23, 23),
(97, 10, '2020-12-10', 23, 23),
(98, 10, '2020-12-10', 23, 23),
(99, 10, '2020-12-10', 23, 23),
(100, 10, '2020-12-10', 23, 23),
(101, 10, '2020-12-10', 23, 23),
(102, 10, '2020-12-10', 23, 23),
(103, 10, '2020-12-10', 23, 0),
(104, 10, '2020-12-11', 0, 0),
(105, 10, '2020-12-11', 0, 0),
(106, 10, '2020-12-11', 0, 0),
(107, 10, '2020-12-11', 0, 0),
(108, 10, '2020-12-11', 0, 0),
(109, 11, '2020-12-11', 0, 0),
(110, 11, '2020-12-11', 7, 0),
(111, 12, '2020-12-11', 8, 8),
(112, 12, '2020-12-11', 9, 0),
(113, 10, '2020-12-11', 9, 9),
(114, 10, '2020-12-11', 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `TelephoneNumber` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `HashedPassword` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserId`, `FirstName`, `LastName`, `Gender`, `Department`, `TelephoneNumber`, `Email`, `HashedPassword`) VALUES
(1, 'Frost', 'Bailey', NULL, 'Sales', '18764592384', NULL, ''),
(5, 'Frost', 'Bailey', NULL, 'Sales', '18764592384', NULL, 'testing123'),
(6, 'Tiger', 'Lionn', 'Male', 'ICT', '(457) 777-7777', 'Email@gmail.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(7, 'new ', 'coder', 'Male', 'ICT', '(457) 777-7777', 'rctfv@gamil.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(8, 'coder', 'frost', 'Male', 'CA', '(154) 564-1651', 'email.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(9, 'cold', ' nibble', 'Male', 'ICT', '(156) 846-5238', 'testing12@gmail.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(10, 'new', 'coder', 'Female', 'ICT', '(489) 651-9865', 'hello', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(11, 'Luna', 'Oliver', 'Male', 'STR', '(876) 454-6531', 'testing12@gmail.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32'),
(12, 'ssyade', 'Gayle', 'Female', 'STR', '(876) 565-1166', 'ssyade@gmail.com', 'b822f1cd2dcfc685b47e83e3980289fd5d8e3ff3a82def24d7d1d68bb272eb32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `appointmentdb`
--
ALTER TABLE `appointmentdb`
  ADD PRIMARY KEY (`idappointmentDb`);

--
-- Indexes for table `conversation_category`
--
ALTER TABLE `conversation_category`
  ADD PRIMARY KEY (`categoryId`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Department_Id`);

--
-- Indexes for table `maria_convo_keyword`
--
ALTER TABLE `maria_convo_keyword`
  ADD PRIMARY KEY (`idmaria_convo`);

--
-- Indexes for table `maria_convo_response`
--
ALTER TABLE `maria_convo_response`
  ADD PRIMARY KEY (`idmaria_convo`);

--
-- Indexes for table `timesheet`
--
ALTER TABLE `timesheet`
  ADD PRIMARY KEY (`idTimeSheet`),
  ADD KEY `FK_User_Timestamp` (`userId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointmentdb`
--
ALTER TABLE `appointmentdb`
  MODIFY `idappointmentDb` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `conversation_category`
--
ALTER TABLE `conversation_category`
  MODIFY `categoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `maria_convo_keyword`
--
ALTER TABLE `maria_convo_keyword`
  MODIFY `idmaria_convo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `maria_convo_response`
--
ALTER TABLE `maria_convo_response`
  MODIFY `idmaria_convo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `timesheet`
--
ALTER TABLE `timesheet`
  MODIFY `idTimeSheet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `timesheet`
--
ALTER TABLE `timesheet`
  ADD CONSTRAINT `FK_User_Timestamp` FOREIGN KEY (`userId`) REFERENCES `user` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
